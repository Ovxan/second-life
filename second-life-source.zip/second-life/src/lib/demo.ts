import plantPhoto from "../assets/plant.jpg";
import bagPhoto from "../assets/bag.jpg";
import lampPhoto from "../assets/lamp.jpg";
import booksPhoto from "../assets/books.jpg";
import chairPhoto from "../assets/chair.jpg";
import deskPhoto from "../assets/desk.jpg";
import type { Listing } from "./types";
const base = { location: "Sekitar kampus ITS, Surabaya", sellerName: "Penjual contoh", phone: "", status: "Tersedia", createdAt: 1793548800000, demo: true, mine: false };
export const demoListings: Listing[] = [
  { ...base, id: "demo-desk", kind: "jual", title: "Meja belajar untuk sudut produktifmu", category: "Furnitur", price: 175000, condition: "Baik", photo: deskPhoto, description: "Contoh iklan meja belajar. Tersedia ruang untuk laptop, buku, dan perlengkapan kuliah. Pada iklan asli, cantumkan ukuran, lama pemakaian, serta bagian yang memiliki bekas penggunaan." },
  { ...base, id: "demo-chair", kind: "jual", title: "Kursi nyaman, teman nugas sampai malam", category: "Furnitur", price: 125000, condition: "Baik", photo: chairPhoto, description: "Contoh iklan kursi. Lengkapi iklan asli dengan bahan, ukuran, kondisi dudukan, dan detail kekurangan barang. Foto ini merupakan ilustrasi." },
  { ...base, id: "demo-books", kind: "donasi", title: "Buku bacaan, siap pindah rak", category: "Buku & Kuliah", price: 0, condition: "Cukup baik", photo: booksPhoto, description: "Contoh donasi buku yang masih layak dibaca. Untuk barang asli, tuliskan judul buku, jumlah, kondisi halaman, dan cara pengambilannya." },
  { ...base, id: "demo-lamp", kind: "jual", title: "Lampu untuk kamar yang lebih hangat", category: "Perlengkapan Kos", price: 85000, condition: "Baik", photo: lampPhoto, description: "Contoh iklan lampu. Jelaskan jenis bohlam, kelengkapan kabel, daya, dan kondisi sakelar pada iklan barangmu." },
  { ...base, id: "demo-bag", kind: "jual", title: "Tas ransel untuk aktivitas kampus", category: "Fashion & Hobi", price: 95000, condition: "Baik", photo: bagPhoto, description: "Contoh iklan tas ransel. Untuk iklan asli, cantumkan kapasitas, kondisi ritsleting, kompartemen, dan bagian yang mengalami keausan." },
  { ...base, id: "demo-plant", kind: "donasi", title: "Tanaman kecil, suasana kos baru", category: "Perlengkapan Kos", price: 0, condition: "Baik", photo: plantPhoto, description: "Contoh donasi tanaman beserta pot. Pada iklan asli, sertakan jenis tanaman, ukuran pot, kebutuhan perawatan, dan lokasi pengambilan." },
];
