export type Kind = "jual" | "donasi" | "jasa";
export type Listing = {
  id: string; kind: Kind; title: string; category: string; description: string;
  condition: string; location: string; price: number; photo: string;
  sellerName: string; phone: string; status: string; createdAt: number;
  mine?: boolean; demo?: boolean;
};
export const categories = ["Semua", "Furnitur", "Elektronik", "Buku & Kuliah", "Perlengkapan Kos", "Fashion & Hobi"];
export const conditions = ["Seperti baru", "Baik", "Cukup baik", "Perlu perbaikan"];
export function statuses(kind: Kind) { return kind === "jasa" ? ["Tersedia", "Nonaktif"] : kind === "donasi" ? ["Tersedia", "Dalam proses", "Tersalurkan"] : ["Tersedia", "Dalam proses", "Terjual"]; }
export function money(value: number) { return new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(value); }
