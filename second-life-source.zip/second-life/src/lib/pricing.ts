import { money, type Kind } from './types';

// Added to the buyer's item price. This is a quote, not a payment receipt.
export const ADMIN_FEE = 5000;
export const PAYMENT_NOTE = 'Penagihan biaya admin belum tersedia. Web belum menerima atau memotong pembayaran.';

export function saleQuote(price: number) {
  if (!Number.isInteger(price) || price < 1000 || price > 100000000) {
    throw new Error('Harga barang harus berupa rupiah utuh antara Rp1.000 dan Rp100.000.000.');
  }
  return { itemPrice: price, adminFee: ADMIN_FEE, buyerTotal: price + ADMIN_FEE, sellerReceives: price };
}

export function catalogPrice(item: { kind: Kind; price: number }) {
  return item.kind === 'jual' ? saleQuote(item.price).buyerTotal : 0;
}

export function pricingText(item: { kind: Kind; price: number }) {
  if (item.kind === 'donasi') return 'Donasi gratis · tanpa biaya admin';
  if (item.kind === 'jasa') return 'Biaya jasa sesuai kesepakatan · tanpa biaya admin platform';
  const q = saleQuote(item.price);
  return `Harga barang: ${money(q.itemPrice)}\nBiaya admin Second Life: ${money(q.adminFee)}\nTotal barang + admin: ${money(q.buyerTotal)}\nBagian penjual: ${money(q.sellerReceives)}\n${PAYMENT_NOTE}`;
}
