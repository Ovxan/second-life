import { money, type Kind } from './types';

// The buyer pays the listed price. The seller owes a fixed fee only after Terjual.
export const ADMIN_FEE = 5000;
export const PAYMENT_NOTE = 'Pembeli membayar harga barang kepada penjual. Tagihan admin Rp5.000 diterbitkan ke akun penjual setelah status Terjual. Penjual mentransfer biaya tersebut ke pengelola dan pembayaran dinyatakan lunas setelah diverifikasi.';

export function saleQuote(price: number) {
  if (!Number.isInteger(price) || price < 1000 || price > 100000000) {
    throw new Error('Harga barang harus berupa rupiah utuh antara Rp1.000 dan Rp100.000.000.');
  }
  return { itemPrice: price, adminFee: ADMIN_FEE, buyerTotal: price, sellerReceives: price - ADMIN_FEE };
}

export function catalogPrice(item: { kind: Kind; price: number }) {
  return item.kind === 'jual' ? saleQuote(item.price).buyerTotal : 0;
}

export function pricingText(item: { kind: Kind; price: number }) {
  if (item.kind === 'donasi') return 'Donasi gratis · tanpa biaya admin';
  if (item.kind === 'jasa') return 'Biaya jasa sesuai kesepakatan · tanpa biaya admin platform';
  const q = saleQuote(item.price);
  return `Harga barang / pembayaran pembeli: ${money(q.buyerTotal)}\nBiaya admin untuk penjual setelah Terjual: ${money(q.adminFee)}\nSisa penjual setelah biaya admin: ${money(q.sellerReceives)}\n${PAYMENT_NOTE}`;
}
