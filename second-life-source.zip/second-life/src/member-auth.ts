import { createClient, type SupabaseClient, type User } from '@supabase/supabase-js';
import config from './backend-config.json';

export type Member = { id: string; name: string; email: string; canPost: boolean; canPublish?: boolean; reviewedName?: string; reviewedCampus?: string };
let client: SupabaseClient | null = null;
const passwordPending = 'second-life-password-pending';
const origin = 'https://ovxan.github.io/second-life/';
export function memberClient() {
  // Preserve the original storage key so existing guest-owned listings can be
  // kept when that same guest identity is linked to a verified email account.
  if (!client) client = createClient(config.url, config.publishableKey, { auth: {
    persistSession: true, autoRefreshToken: true, detectSessionInUrl: true,
  } });
  return client;
}
export function authMessage(error: { message?: string; code?: string; status?: number } | null) {
  const text = `${error?.code || ''} ${error?.message || ''}`;
  if (/email_address_not_authorized|not authorized|smtp|email.*sending/i.test(text)) return 'Email verifikasi belum dapat dikirim. Pengelola perlu mengaktifkan layanan pengiriman email untuk pendaftaran umum.';
  if (error?.status === 429 || /rate.limit|too many/i.test(text)) return 'Terlalu banyak percobaan. Tunggu beberapa saat sebelum mencoba lagi.';
  if (/email_not_confirmed/i.test(text)) return 'Konfirmasi email melalui pesan verifikasi terlebih dahulu, lalu masuk kembali.';
  if (/weak_password|password.*least/i.test(text)) return 'Gunakan password minimal 8 karakter dengan huruf dan angka.';
  if (/fetch|network/i.test(text)) return 'Koneksi terputus. Periksa internet dan coba lagi.';
  return 'Proses akun belum berhasil. Periksa data, email verifikasi, lalu coba lagi.';
}
function checked(error: { message?: string; code?: string; status?: number } | null) { if (error) throw new Error(authMessage(error)); }
export function validPassword(password: string) {
  return password.length >= 8 && /[A-Za-z]/.test(password) && /[0-9]/.test(password);
}
function member(user: User, canPost: boolean, campus?: {can_publish?: boolean; reviewed?: boolean; full_name?: string; campus?: string}): Member {
  return { id: user.id, name: String(user.user_metadata?.name || '').slice(0,70), email: user.email || '', canPost,
    canPublish: canPost && campus?.can_publish === true,
    reviewedName: campus?.reviewed ? campus.full_name : undefined, reviewedCampus: campus?.reviewed ? campus.campus : undefined };
}
export async function currentMember(): Promise<Member | null> {
  const connection = memberClient();
  const { data: session } = await connection.auth.getSession();
  if (!session.session || session.session.user.is_anonymous) return null;
  const { data, error } = await connection.auth.getUser();
  if (error || !data.user || data.user.is_anonymous) return null;
  const result = await connection.rpc('has_registered_account');
  const registered = !result.error && result.data === true;
  const campus = registered ? await connection.rpc('campus_account_access') : null;
  return member(data.user, registered, campus && !campus.error ? campus.data : undefined);
}
export async function requireMember() {
  const user = await currentMember();
  if (!user?.canPost) throw new Error('Daftar, konfirmasi email, dan login terlebih dahulu sebelum menambahkan barang.');
  return user;
}
export async function legacySession() {
  const { data } = await memberClient().auth.getSession();
  return !!data.session?.user.is_anonymous;
}
export async function signUpMember(name: string, email: string, password: string) {
  if (name.trim().length < 2 || name.trim().length > 70) throw new Error('Isi nama antara 2–70 karakter.');
  const connection = memberClient();
  const { data: session } = await connection.auth.getSession();
  if (session.session?.user.is_anonymous) {
    // Supabase requires verification before a converted guest can set a password.
    const result = await connection.auth.updateUser({ email: email.trim(), data: { name: name.trim() } }, { emailRedirectTo: origin + '?account=verified' });
    checked(result.error);
    try { localStorage.setItem(passwordPending, session.session.user.id); } catch {}
    return 'Buka email verifikasi dari perangkat dan browser yang sama. Setelah email dikonfirmasi, atur password untuk menyelesaikan pendaftaran dan mempertahankan akses iklan lama.';
  }
  if (!validPassword(password)) throw new Error('Password minimal 8 karakter dan memuat huruf serta angka.');
  const result = await connection.auth.signUp({ email: email.trim(), password, options: { data: { name: name.trim() }, emailRedirectTo: origin + '?account=verified' } });
  checked(result.error);
  return 'Periksa email dan folder spam untuk mengonfirmasi akun. Setelah itu, login dengan email dan password untuk memasang barang.';
}
export async function signInMember(email: string, password: string) {
  const connection = memberClient();
  const { error } = await connection.auth.signInWithPassword({ email: email.trim(), password });
  if (error) {
    if (error.code === 'invalid_credentials') throw new Error('Email atau password tidak sesuai.');
    checked(error);
  }
  const user = await currentMember();
  if (!user?.canPost) throw new Error('Akun belum selesai diverifikasi. Periksa email verifikasi dan lengkapi password.');
  return user;
}
export async function setMemberPassword(password: string) {
  if (!validPassword(password)) throw new Error('Password minimal 8 karakter dan memuat huruf serta angka.');
  const { error } = await memberClient().auth.updateUser({ password }); checked(error);
  const user = await currentMember();
  if (!user?.canPost) throw new Error('Konfirmasi email terlebih dahulu sebelum mengatur password.');
  localStorage.removeItem(passwordPending);
  return user;
}
export function needsPassword(user: Member | null) { if (!user) return false; if (!user.canPost) return true; try { return localStorage.getItem(passwordPending) === user.id; } catch { return false; } }
export async function resetMemberPassword(email: string) {
  const { error } = await memberClient().auth.resetPasswordForEmail(email.trim(), { redirectTo: origin + '?account=recovery' }); checked(error);
  return 'Jika alamat tersebut terdaftar, tautan pengaturan password akan dikirim ke email. Periksa juga folder spam.';
}
export async function signOutMember() { const { error } = await memberClient().auth.signOut({ scope: 'local' }); checked(error); }
export function subscribeMember(callback: (event: string) => void) {
  const { data } = memberClient().auth.onAuthStateChange(event => { if (event !== 'INITIAL_SESSION') setTimeout(()=>callback(event),0); });
  return () => data.subscription.unsubscribe();
}
