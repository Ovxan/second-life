import React from 'react';
import { createRoot } from 'react-dom/client';
import Marketplace from './marketplace';
createRoot(document.getElementById('root')!).render(<Marketplace />);
