import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import config from './backend-config.json';

export type AdminAccess = { isAdmin: boolean; email: string; userId?: string };
export const noAdmin: AdminAccess = { isAdmin: false, email: '' };
let client: SupabaseClient | null = null;
export function adminClient() {
  if (!client) client = createClient(config.url, config.publishableKey, { auth: {
    storageKey: 'second-life-site-admin-auth-v1', persistSession: true,
    autoRefreshToken: true, detectSessionInUrl: false,
  } });
  return client;
}
export async function adminAccess(): Promise<AdminAccess> {
  const connection = adminClient();
  const { data: session, error: sessionError } = await connection.auth.getSession();
  if (sessionError || !session.session) return noAdmin;
  // Validate the identity with Auth; local storage and user_metadata grant no role.
  const { data, error } = await connection.auth.getUser();
  if (error || !data.user || data.user.is_anonymous) return noAdmin;
  const role = await connection.rpc('is_site_admin');
  if (role.error || role.data !== true) return noAdmin;
  return { isAdmin: true, email: data.user.email || '', userId: data.user.id };
}
export async function requireSiteAdmin() {
  const access = await adminAccess();
  if (!access.isAdmin || !access.userId) throw new Error('Hanya pemilik web yang sudah login dan diberi akses admin yang dapat melakukan perubahan ini.');
  return { connection: adminClient(), userId: access.userId };
}
export async function signInAdmin(email: string, password: string) {
  if (!email.trim() || !password) throw new Error('Isi email admin dan password.');
  const connection = adminClient();
  const result = await connection.auth.signInWithPassword({ email: email.trim(), password });
  if (result.error) {
    if (result.error.status === 429 || /rate.limit/i.test(result.error.code || '')) throw new Error('Terlalu banyak percobaan masuk. Coba lagi beberapa saat lagi.');
    throw new Error('Email atau password tidak sesuai, atau akun belum aktif.');
  }
  const access = await adminAccess();
  if (!access.isAdmin) {
    await connection.auth.signOut({ scope: 'local' });
    throw new Error('Akun ini belum diberi akses admin pemilik web. Hubungi pemilik web untuk mengaktifkannya.');
  }
  return access;
}
export async function signOutAdmin() {
  const { error } = await adminClient().auth.signOut({ scope: 'local' });
  if (error) throw new Error('Belum dapat keluar dari sesi admin. Coba lagi.');
}
export function subscribeAdmin(callback: () => void) {
  const { data } = adminClient().auth.onAuthStateChange(event => {
    if (event !== 'INITIAL_SESSION') setTimeout(callback, 0);
  });
  return () => data.subscription.unsubscribe();
}
