import { useState, type FormEvent } from 'react';
import { ShieldCheck, LogIn, LoaderCircle, Info } from 'lucide-react';
import { signInAdmin, type AdminAccess } from '../admin-auth';

export function AdminLogin({ signedIn }: { signedIn: (access: AdminAccess) => Promise<void> }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  async function submit(event: FormEvent) {
    event.preventDefault(); setBusy(true); setError('');
    try { const access = await signInAdmin(email, password); setPassword(''); await signedIn(access); }
    catch (e) { setError((e as Error).message); setPassword(''); }
    finally { setBusy(false); }
  }
  return <section className="admin-login" aria-label="Login admin pemilik web"><div className="admin-login-icon"><ShieldCheck size={30} /></div>
    <div className="eyebrow">KHUSUS PENGELOLA</div><h1>Masuk mode admin</h1>
    <p>Login sebagai pemilik untuk mengelola seluruh iklan jual beli, donasi, dan jasa reparasi. Pengunjung tetap bisa menjelajah tanpa login.</p>
    <form onSubmit={submit}>
      <label>Email admin<input type="email" name="admin_email" autoComplete="username" required value={email} disabled={busy} onChange={e => setEmail(e.target.value)} placeholder="Email akun admin" /></label>
      <label>Password<input type="password" name="admin_password" autoComplete="current-password" required value={password} disabled={busy} onChange={e => setPassword(e.target.value)} placeholder="Password akun admin" /></label>
      {error && <div className="error-banner" role="alert"><Info size={17} /><span>{error}</span></div>}
      <button className="button primary full" disabled={busy} type="submit">{busy ? <LoaderCircle size={18} className="spin" /> : <LogIn size={18} />}{busy ? 'Memeriksa akses…' : 'Masuk sebagai admin'}</button>
    </form><p className="admin-login-help">Akun admin dibuat dan diaktifkan oleh pemilik web. Tidak ada pendaftaran admin umum.</p>
  </section>;
}
