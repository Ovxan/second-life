import { ADMIN_FEE, PAYMENT_NOTE, saleQuote } from '../lib/pricing';
import { money, type Kind } from '../lib/types';

export function ListingPrice({ kind, price }: { kind: Kind; price: number }) {
  if (kind === 'donasi') return <div className="price free">Gratis <span>tanpa biaya admin</span></div>;
  if (kind === 'jasa') return <div className="price">Hubungi penyedia jasa</div>;
  const quote = saleQuote(price);
  return <div className="listing-price"><div className="price">{money(quote.buyerTotal)}<span className="total-label">barang + admin</span></div><p>{money(quote.itemPrice)} + admin {money(quote.adminFee)}</p></div>;
}

export function PriceBreakdown({ price, preview = false }: { price: number; preview?: boolean }) {
  let quote;
  try { quote = saleQuote(price); } catch { /* Empty/invalid form input has no payable total. */ }
  return <section className={`price-breakdown ${preview ? 'price-preview' : ''}`} aria-label="Rincian harga dan biaya admin">
    <div className="price-breakdown-head"><strong>Rincian harga</strong><span>Transparan sejak awal</span></div>
    <dl aria-live={preview ? 'polite' : undefined}>
      <div><dt>Harga barang</dt><dd>{quote ? money(quote.itemPrice) : 'Isi harga barang'}</dd></div>
      <div><dt>Biaya admin Second Life</dt><dd>{money(ADMIN_FEE)}</dd></div>
      <div className="price-total"><dt>Total barang + admin</dt><dd>{quote ? money(quote.buyerTotal) : '—'}</dd></div>
      <div className="seller-share"><dt>Bagian penjual</dt><dd>{quote ? money(quote.sellerReceives) : '—'}</dd></div>
    </dl>
    <p>Biaya admin ditambahkan ke harga barang untuk pengelola Second Life, sekali per jual beli yang berhasil. Pengiriman, jika ada, disepakati terpisah.</p>
    <p className="payment-pending">{PAYMENT_NOTE}</p>
  </section>;
}
