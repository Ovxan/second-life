import { ADMIN_FEE, PAYMENT_NOTE, saleQuote } from '../lib/pricing';
import { money, type Kind } from '../lib/types';

export function ListingPrice({ kind, price }: { kind: Kind; price: number }) {
  if (kind === 'donasi') return <div className="price free">Gratis <span>tanpa biaya admin</span></div>;
  if (kind === 'jasa') return <div className="price">Hubungi penyedia jasa</div>;
  const quote = saleQuote(price);
  return <div className="listing-price"><div className="price">{money(quote.buyerTotal)}<span className="total-label">harga barang</span></div></div>;
}

export function PriceBreakdown({ price, preview = false }: { price: number; preview?: boolean }) {
  let quote;
  try { quote = saleQuote(price); } catch { /* Empty/invalid form input has no payable total. */ }
  return <section className={`price-breakdown ${preview ? 'price-preview' : ''}`} aria-label="Rincian harga dan biaya admin">
    <div className="price-breakdown-head"><strong>Rincian harga</strong><span>Transparan sejak awal</span></div>
    <dl aria-live={preview ? 'polite' : undefined}>
      <div><dt>Harga barang</dt><dd>{quote ? money(quote.itemPrice) : 'Isi harga barang'}</dd></div>
      <div><dt>Tagihan admin penjual setelah Terjual</dt><dd>{money(ADMIN_FEE)}</dd></div>
      <div className="price-total"><dt>Pembeli membayar</dt><dd>{quote ? money(quote.buyerTotal) : '—'}</dd></div>
      <div className="seller-share"><dt>Sisa penjual setelah admin</dt><dd>{quote ? money(quote.sellerReceives) : '—'}</dd></div>
    </dl>
    <p>Biaya admin menjadi kewajiban penjual kepada pengelola Second Life setelah barang ditandai Terjual, sekali per penjualan yang berhasil. Pengiriman, jika ada, disepakati terpisah.</p>
    {quote && quote.sellerReceives < 0 && <p className="fee-price-warning">Biaya admin lebih besar daripada harga barang. Penjual perlu menambah dana untuk melunasinya; periksa harga sebelum menayangkan.</p>}
    <p className="payment-pending">{PAYMENT_NOTE}</p>
  </section>;
}
