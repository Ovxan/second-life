import { useEffect, useState, type FormEvent } from 'react';
import { UserRound, LoaderCircle, Info, CheckCircle2 } from 'lucide-react';
import { legacySession, needsPassword, resetMemberPassword, setMemberPassword, signInMember, signOutMember, signUpMember, type Member } from '../member-auth';

export function MemberAccount({ user, updated, manage }: { user: Member | null; updated: () => Promise<void>; manage: () => void }) {
  const [mode,setMode]=useState<'login'|'signup'|'reset'|'password'>(()=>needsPassword(user)||new URLSearchParams(location.search).get('account')==='recovery'?'password':'login');
  const [legacy,setLegacy]=useState(false),[name,setName]=useState(''),[email,setEmail]=useState(''),[password,setPassword]=useState(''),[confirmation,setConfirmation]=useState('');
  const [busy,setBusy]=useState(false),[error,setError]=useState(''),[notice,setNotice]=useState('');
  useEffect(()=>{void legacySession().then(setLegacy);},[]);
  useEffect(()=>{if(needsPassword(user))setMode('password');},[user]);
  async function submit(e:FormEvent){
    e.preventDefault();setBusy(true);setError('');setNotice('');
    try {
      if(mode==='login'){await signInMember(email,password);await updated();}
      else if(mode==='reset')setNotice(await resetMemberPassword(email));
      else if(mode==='signup'){
        if(!legacy&&password!==confirmation)throw new Error('Konfirmasi password belum sama.');
        setNotice(await signUpMember(name,email,password));
      } else {
        if(password!==confirmation)throw new Error('Konfirmasi password belum sama.');
        await setMemberPassword(password);setNotice('Password tersimpan. Akun siap digunakan.');setMode('login');await updated();
      }
      setPassword('');setConfirmation('');
    }catch(e){setError((e as Error).message);}finally{setBusy(false);}
  }
  if(user?.canPost&&mode!=='password')return <section className="admin-login"><div className="admin-login-icon"><UserRound size={30}/></div><h1>Akun kamu</h1><p><strong>{user.name||'Pengguna Second Life'}</strong><br/>{user.email}</p><p>Email terverifikasi. Kamu dapat memasang barang dan mengelola iklanmu setelah login dari perangkat mana pun.</p><button className="button primary full" onClick={manage}>Kelola barang saya</button><button className="button secondary full" disabled={busy} onClick={async()=>{setBusy(true);try{await signOutMember();await updated();}catch(e){setError((e as Error).message);}finally{setBusy(false);}}}>Keluar dari akun</button>{error&&<p role="alert">{error}</p>}</section>;
  return <section className="admin-login" aria-label="Akun pengunjung"><div className="admin-login-icon"><UserRound size={30}/></div><div className="eyebrow">KOMUNITAS SECOND LIFE</div><h1>{mode==='signup'?'Daftar akun':mode==='reset'?'Lupa password':mode==='password'?'Atur password':'Masuk ke akun'}</h1><p>{mode==='signup'?'Daftar dan konfirmasi email agar iklan serta tagihan tersimpan pada akunmu.':mode==='password'?'Setelah email dikonfirmasi, tentukan password agar akun dapat dipakai kembali dari perangkat lain.':'Login diperlukan untuk memasang barang, membuat tagihan admin, dan mengunggah bukti pembayaran. Katalog tetap dapat dilihat tanpa akun.'}</p>
    <form onSubmit={submit}>
      {mode==='signup'&&<label>Nama lengkap<input required minLength={2} maxLength={70} autoComplete="name" value={name} onChange={e=>setName(e.target.value)} disabled={busy}/></label>}
      {mode!=='password'&&<label>Email<input type="email" required autoComplete="username" value={email} onChange={e=>setEmail(e.target.value)} disabled={busy}/></label>}
      {(mode==='login'||mode==='password'||(mode==='signup'&&!legacy))&&<label>Password<input type="password" required minLength={mode==='login'?1:8} autoComplete={mode==='login'?'current-password':'new-password'} value={password} onChange={e=>setPassword(e.target.value)} disabled={busy}/></label>}
      {(mode==='password'||(mode==='signup'&&!legacy))&&<><label>Ulangi password<input type="password" required minLength={8} autoComplete="new-password" value={confirmation} onChange={e=>setConfirmation(e.target.value)} disabled={busy}/></label><small>Minimal 8 karakter, gunakan huruf dan angka.</small></>}
      {mode==='signup'&&legacy&&<div className="notice"><Info size={18}/><p>Ada sesi pengunjung lama pada browser ini. Konfirmasi email terlebih dahulu, kemudian atur password supaya akses iklan lama tetap terhubung.</p></div>}
      {error&&<div className="error-banner" role="alert"><Info size={17}/><span>{error}</span></div>}
      {notice&&<div className="notice" role="status"><CheckCircle2 size={18}/><p>{notice}</p></div>}
      <button className="button primary full" disabled={busy} type="submit">{busy&&<LoaderCircle size={18} className="spin"/>}{busy?'Memproses…':mode==='signup'?'Daftar dan verifikasi email':mode==='reset'?'Kirim tautan pengaturan':mode==='password'?'Simpan password':'Masuk'}</button>
    </form><div className="account-switch">{mode!=='login'&&<button className="text-button" disabled={busy} onClick={()=>{setMode('login');setError('');setNotice('');}}>Sudah punya akun? Masuk</button>}{mode!=='signup'&&<button className="text-button" disabled={busy} onClick={()=>{setMode('signup');setError('');setNotice('');}}>Daftar akun baru</button>}{mode==='login'&&<button className="text-button" disabled={busy} onClick={()=>{setMode('reset');setError('');setNotice('');}}>Lupa password?</button>}</div>
  </section>;
}
