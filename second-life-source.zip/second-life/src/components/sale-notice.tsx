import { ReceiptText, CheckCircle2 } from 'lucide-react';
import { ADMIN_FEE } from '../lib/pricing';
import { money } from '../lib/types';

export function SalePaymentNotice({title,own,open,close}: {title: string;own: boolean;open: () => void;close: () => void}) {
  return <div className="sale-payment-notice"><div className="fee-intro"><CheckCircle2 size={28}/><div><span className="eyebrow">STATUS TERJUAL</span><h3>Penjualan tercatat</h3></div></div><p><strong>{title}</strong> sudah ditandai Terjual. Tagihan biaya admin otomatis tersimpan di akun penjual.</p><div className="sale-fee-due"><span>Tagihan biaya admin</span><strong>{money(ADMIN_FEE)}</strong></div><p>{own?'Buka tagihan untuk melihat tujuan transfer, membayar biaya admin, dan mengunggah bukti. Kamu juga dapat membukanya kembali melalui Tagihan saya.':'Tagihan ditujukan kepada pemilik asli barang. Kamu dapat memantaunya melalui Penagihan & pendapatan.'}</p><p className="fee-small">Tagihan dibuat otomatis; transfer ke pengelola tetap dilakukan oleh penjual dan diperiksa sebelum dinyatakan Lunas.</p><div className="fee-actions"><button type="button" className="button primary" onClick={open}><ReceiptText size={17}/>{own?'Buka tagihan & pembayaran':'Buka penagihan admin'}</button><button type="button" className="button secondary" onClick={close}>Nanti</button></div></div>;
}
