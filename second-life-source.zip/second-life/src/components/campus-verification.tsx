import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { ArrowLeft, CheckCircle2, FileCheck2, Info, LoaderCircle, RefreshCw, ShieldCheck } from 'lucide-react';
import type { Member } from '../member-auth';
import { campusDocumentUrl, campusRequests, campusStatusLabels, removeCampusDocument, reviewCampusRequest, revokeCampusRequest, submitCampusDocument, subscribeCampus, withdrawCampusRequest, type CampusRequest } from '../campus-api';

const date=(value:string|null)=>value?new Date(value).toLocaleString('id-ID',{dateStyle:'medium',timeStyle:'short'}):'—';
const message=(error:unknown)=>error instanceof Error?error.message:'Proses belum berhasil. Coba kembali.';
function Alert({text}:{text:string}){return text?<div className="error-banner" role="alert"><Info size={17}/><span>{text}</span></div>:null;}

export function CampusReviewLabel({campus}:{campus?:string}){
  return campus?<span className="campus-public-label"><FileCheck2 size={14}/> Dokumen kampus ditinjau admin · {campus}</span>:<span>Dokumen kampus belum ditinjau admin</span>;
}

function RequestCard({request,asAdmin=false,changed}:{request:CampusRequest;asAdmin?:boolean;changed:()=>Promise<void>}){
  const [busy,setBusy]=useState(false),[error,setError]=useState(''),[notice,setNotice]=useState('');
  const [photo,setPhoto]=useState(''),[seen,setSeen]=useState(false),[checked,setChecked]=useState(false),[note,setNote]=useState(''),[confirmWithdraw,setConfirmWithdraw]=useState(false),[confirmRevoke,setConfirmRevoke]=useState(false);
  useEffect(()=>{if(!photo)return;const timer=setTimeout(()=>setPhoto(''),60000);return()=>clearTimeout(timer);},[photo]);
  useEffect(()=>{if(request.status!=='pending'){setPhoto('');setChecked(false);}},[request.status]);
  async function action(operation:()=>Promise<string|void>){setBusy(true);setError('');setNotice('');try{const result=await operation();if(result)setNotice(result);setPhoto('');setConfirmWithdraw(false);setConfirmRevoke(false);await changed();}catch(error){setError(message(error));await changed().catch(()=>{});}finally{setBusy(false);}}
  const active=['draft','pending','approved'].includes(request.status);
  return <article className="campus-request">
    <div className="campus-request-heading"><div><strong>{request.full_name}</strong><span>{request.campus} · {request.document_kind==='ktm'?'KTM':'Bukti alumni'}</span><small>Diajukan {date(request.submitted_at||request.created_at)}</small></div><span className={'campus-status '+request.status}>{campusStatusLabels[request.status]}</span></div>
    {request.reviewed_at&&<p className="campus-small">Diperiksa {date(request.reviewed_at)}{request.review_note?' · '+request.review_note:''}</p>}
    {request.status==='revoked'&&<p className="campus-small">Alasan pencabutan: {request.revoke_note}</p>}
    {request.status==='approved'&&<p className="campus-small">Nama pada iklan baru mengikuti nama dokumen yang disetujui. Label hanya menunjukkan pemeriksaan manual dokumen, bukan jaminan transaksi atau validasi database kampus.</p>}
    <p className="campus-small">{request.document_deleted_at?'Foto dokumen telah dihapus. Hasil pemeriksaan tetap tersimpan.':request.status==='pending'||request.status==='draft'?'Foto bersifat privat untuk pemeriksaan pengajuan.':'Foto menunggu penghapusan.'}</p>
    {!request.document_deleted_at&&<div className="campus-document-actions"><button type="button" className="text-button" disabled={busy} onClick={async()=>{setBusy(true);setError('');try{setPhoto(await campusDocumentUrl(request,asAdmin));setSeen(true);}catch(error){setError(message(error));}finally{setBusy(false);}}}>Lihat foto dokumen</button>{request.status!=='pending'&&<button className="text-button" type="button" disabled={busy} onClick={()=>void action(()=>removeCampusDocument(request,asAdmin))}>Hapus foto dokumen</button>}</div>}
    {photo&&<div className="campus-document"><img src={photo} alt="Dokumen kampus privat untuk pemeriksaan" referrerPolicy="no-referrer"/><small>Akses gambar berakhir dalam satu menit. Buka kembali jika masih diperlukan.</small><button type="button" className="text-button" onClick={()=>setPhoto('')}>Tutup foto</button></div>}
    {asAdmin&&request.status==='pending'&&<form className="fee-form campus-review-form" onSubmit={event=>{event.preventDefault();if(seen&&checked)void action(()=>reviewCampusRequest(request,true,note));}}>
      <p>Cocokkan nama dan kampus pada foto dengan pengajuan. Minta perbaikan bila dokumen tidak jelas, tidak sesuai, atau meragukan.</p>
      <label>Catatan pemeriksaan / alasan perbaikan<textarea maxLength={300} rows={2} value={note} onChange={event=>setNote(event.target.value)} disabled={busy}/></label>
      <label className="fee-checkbox"><input type="checkbox" checked={checked} disabled={!seen||busy} onChange={event=>setChecked(event.target.checked)}/><span>Saya sudah membuka foto dan mencocokkan nama serta kampus pada dokumen ini.</span></label>
      <div className="fee-actions"><button type="submit" className="button primary" disabled={busy||!seen||!checked}>Setujui pengajuan</button><button type="button" className="button secondary" disabled={busy||note.trim().length<3} onClick={()=>void action(()=>reviewCampusRequest(request,false,note))}>Minta perbaikan</button></div>
      <small>Foto akan dihapus setelah keputusan. Jika penghapusan gagal, gunakan Hapus foto dokumen; keputusan tetap tersimpan.</small>
    </form>}
    {!asAdmin&&active&&<div className="campus-withdraw">{!confirmWithdraw?<button type="button" className="text-button" disabled={busy} onClick={()=>setConfirmWithdraw(true)}>{request.status==='approved'?'Cabut verifikasi saya':'Tarik pengajuan'}</button>:<><p>Pengajuan ditarik dan foto dihapus. Persetujuan memasang barang baru serta label pemeriksaan akan berhenti berlaku; iklan lama dan tagihan tetap tersimpan.</p><div className="fee-actions"><button type="button" className="button secondary" disabled={busy} onClick={()=>setConfirmWithdraw(false)}>Kembali</button><button type="button" className="button destructive" disabled={busy} onClick={()=>void action(()=>withdrawCampusRequest(request))}>Ya, tarik pengajuan</button></div></>}</div>}
    {asAdmin&&request.status==='approved'&&<div className="campus-withdraw">{!confirmRevoke?<button type="button" className="text-button" disabled={busy} onClick={()=>setConfirmRevoke(true)}>Cabut persetujuan</button>:<form className="fee-form" onSubmit={event=>{event.preventDefault();void action(()=>revokeCampusRequest(request.id,note));}}><p>Pencabutan menghentikan pemasangan iklan baru dan label dokumen ditinjau pada akun ini.</p><label>Alasan pencabutan<input required minLength={3} maxLength={300} value={note} onChange={event=>setNote(event.target.value)}/></label><div className="fee-actions"><button type="button" className="button secondary" onClick={()=>setConfirmRevoke(false)}>Kembali</button><button className="button destructive" disabled={busy} type="submit">Konfirmasi pencabutan</button></div></form>}</div>}
    {busy&&<p className="campus-small" role="status"><LoaderCircle size={16} className="spin"/> Memproses…</p>}<Alert text={error}/>{notice&&<p className="campus-small" role="status">{notice}</p>}
  </article>;
}

export function CampusVerificationPanel({user,updated}:{user:Member;updated:()=>Promise<void>}){
  const [requests,setRequests]=useState<CampusRequest[]>([]),[loading,setLoading]=useState(true),[busy,setBusy]=useState(false),[error,setError]=useState(''),[fetchError,setFetchError]=useState(''),[notice,setNotice]=useState('');
  const [name,setName]=useState(user.reviewedName||user.name),[campus,setCampus]=useState(''),[kind,setKind]=useState<'ktm'|'alumni'>('ktm'),[file,setFile]=useState<File|null>(null),[consent,setConsent]=useState(false);
  const load=useCallback(async()=>{try{setRequests(await campusRequests());setFetchError('');}catch(error){setFetchError(message(error));}finally{setLoading(false);}},[user.id]);
  useEffect(()=>{void load();return subscribeCampus(()=>{void load();void updated();});},[load]);
  const changed=async()=>{await load();await updated();};
  const active=requests.find(request=>['draft','pending','approved'].includes(request.status));
  async function submit(event:FormEvent){event.preventDefault();if(!file){setError('Pilih foto dokumen terlebih dahulu.');return;}setBusy(true);setError('');setNotice('');try{await submitCampusDocument({name,campus,kind,file,consent});setFile(null);setConsent(false);setNotice('Pengajuan terkirim. Tunggu pemeriksaan admin sebelum memasang barang baru.');}catch(error){setError(message(error));}finally{await changed();setBusy(false);}}
  return <section className="campus-panel" aria-label="Verifikasi dokumen kampus"><div className="campus-panel-title"><FileCheck2 size={23}/><div><h2>Verifikasi dokumen kampus</h2><p>KTM untuk mahasiswa, kartu atau surat keterangan alumni untuk alumni.</p></div></div>
    <p>Konfirmasi email memberi akses akun. Pemasangan barang baru memerlukan persetujuan dokumen dari admin. Kamu tetap dapat mengelola iklan lama dan membayar tagihan selama menunggu.</p>
    <Alert text={error}/><Alert text={fetchError}/>{notice&&<div className="fee-success" role="status"><CheckCircle2 size={18}/>{notice}</div>}
    {loading?<p role="status">Memuat status pengajuan…</p>:<>{active&&<RequestCard key={active.id} request={active} changed={changed}/>}
    {!active&&!fetchError&&<form className="fee-form campus-submit" onSubmit={submit}>
      <label>Nama lengkap sesuai dokumen<input required minLength={2} maxLength={70} autoComplete="name" value={name} onChange={event=>setName(event.target.value)} disabled={busy}/></label>
      <label>Nama kampus<input required minLength={2} maxLength={120} value={campus} placeholder="Nama perguruan tinggi" onChange={event=>setCampus(event.target.value)} disabled={busy}/></label>
      <label>Jenis dokumen<select value={kind} disabled={busy} onChange={event=>setKind(event.target.value as 'ktm'|'alumni')}><option value="ktm">Kartu Tanda Mahasiswa (KTM)</option><option value="alumni">Kartu / surat keterangan alumni</option></select></label>
      <div className="fee-notice"><Info size={18}/><p>Tampilkan nama dan kampus dengan jelas. Tutup NIM, NIK, alamat, nomor rekening, serta barcode/QR yang tidak diperlukan. Jangan unggah KTP. Pemeriksaan dilakukan manual, tanpa pencocokan database kampus.</p></div>
      <label>Foto dokumen kampus<input key={requests.length} type="file" required accept="image/jpeg,image/png,image/webp" disabled={busy} onChange={event=>setFile(event.target.files?.[0]||null)}/><small>JPG, PNG, atau WebP, maksimal 2 MB. Jangan kirim dokumen melalui chat.</small></label>
      <div className="campus-privacy"><strong>Penggunaan dokumen</strong><p>Foto hanya dapat diakses akunmu dan admin pemilik untuk menilai pengajuan. Selama pengajuan aktif, foto disimpan privat. Setelah keputusan atau penarikan, foto dihapus; jika gagal, status penghapusan ditampilkan untuk ditindaklanjuti.</p><p>Nama, kampus, persetujuan, dan riwayat keputusan tetap tersimpan selama akun digunakan. Pada iklan dengan nama yang sesuai, publik dapat melihat nama, kampus, dan label pemeriksaan. Foto dokumen tidak dipublikasikan. Kamu dapat menarik pengajuan atau mencabut verifikasi dari halaman ini.</p></div>
      <label className="fee-checkbox"><input type="checkbox" required checked={consent} disabled={busy} onChange={event=>setConsent(event.target.checked)}/><span>Saya mengajukan dokumen milik sendiri dan menyetujui penggunaan data sesuai penjelasan di atas.</span></label>
      <button type="submit" className="button primary full" disabled={busy||!consent||!file}>{busy?<LoaderCircle className="spin" size={18}/>:<FileCheck2 size={18}/>} {busy?'Mengirim pengajuan…':'Kirim untuk diperiksa'}</button>
    </form>}
    {!!requests.filter(request=>request.id!==active?.id).length&&<details className="campus-history"><summary>Riwayat pengajuan</summary>{requests.filter(request=>request.id!==active?.id).map(request=><RequestCard key={request.id} request={request} changed={changed}/>)}</details>}</>}
    <button type="button" className="text-button" disabled={loading||busy} onClick={()=>{setLoading(true);void changed();}}><RefreshCw size={15}/> Perbarui status</button>
  </section>;
}

export function CampusAdminWorkspace({back}:{back:()=>void}){
  const [requests,setRequests]=useState<CampusRequest[]>([]),[filter,setFilter]=useState('pending'),[loading,setLoading]=useState(true),[error,setError]=useState('');
  const load=useCallback(async()=>{setLoading(true);setError('');try{setRequests(await campusRequests(true,filter));}catch(error){setError(message(error));}finally{setLoading(false);}},[filter]);
  useEffect(()=>{void load();return subscribeCampus(()=>{void load();});},[load]);
  return <section className="container campus-admin-page"><button type="button" className="back-link" onClick={back}><ArrowLeft size={15}/> Kembali ke dashboard pemilik</button><div className="billing-heading"><div><span className="eyebrow">RUANG PEMILIK SECOND LIFE</span><h1>Pemeriksaan dokumen kampus</h1><p>Tinjau KTM atau bukti alumni, putuskan pengajuan, lalu hapus foto dokumen setelah pemeriksaan.</p></div><button type="button" className="button secondary" disabled={loading} onClick={()=>void load()}><RefreshCw size={16}/> Perbarui</button></div>
    <div className="fee-notice"><ShieldCheck size={20}/><p>Persetujuan membuka pemasangan barang baru. Pemeriksaan ini bersifat manual; jangan menyebutnya validasi resmi kampus atau jaminan transaksi. Iklan lama tetap tersimpan. Akun pemilik mengelola platform melalui peran admin tersendiri.</p></div>
    <label className="campus-filter">Status pengajuan<select value={filter} onChange={event=>setFilter(event.target.value)}><option value="all">Semua status</option>{Object.entries(campusStatusLabels).map(([value,label])=><option key={value} value={value}>{label}</option>)}</select></label><Alert text={error}/>
    {loading&&<p role="status">Memuat pengajuan…</p>}{!loading&&!error&&!requests.length&&<div className="fee-empty"><FileCheck2 size={34}/><h3>Belum ada pengajuan pada status ini.</h3><p>Pengajuan penjual akan tampil setelah foto dokumen berhasil dikirim.</p></div>}
    <div className="campus-admin-list">{requests.map(request=><RequestCard key={request.id} request={request} asAdmin changed={load}/>)}</div>{requests.length===200&&<p className="campus-small">Menampilkan 200 pengajuan terbaru pada status yang dipilih. Persempit status untuk melihat antrean pemeriksaan.</p>}
  </section>;
}
