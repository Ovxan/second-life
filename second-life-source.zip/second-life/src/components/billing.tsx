import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { ArrowLeft, ArrowUpRight, CheckCircle2, Info, LoaderCircle, ReceiptText, RefreshCw, ShieldCheck, Upload } from 'lucide-react';
import { ADMIN_FEE } from '../lib/pricing';
import { money, type Listing } from '../lib/types';
import { billingData, cancelFeeInvoice, createFeeInvoice, feeHistory, feeProofUrl, feeStatusLabels, invoiceCode, paymentReady, reviewFeeProof, savePaymentSettings, submitFeeProof, type FeeEvent, type FeeInvoice, type FeeSummary, type PaymentSettings } from '../billing-api';

const date = (value: string) => new Date(value).toLocaleString('id-ID',{dateStyle:'medium',timeStyle:'short'});
const message = (error: unknown) => error instanceof Error ? error.message : 'Permintaan belum berhasil. Coba lagi.';
const eventLabels: Record<string,string> = { created:'Tagihan dibuat',proof_submitted:'Bukti dikirim',proof_rejected:'Perbaikan diminta',paid:'Transfer dikonfirmasi',cancelled:'Tagihan dibatalkan' };
function Alert({text}: {text: string}) { return text ? <div className="error-banner" role="alert"><Info size={18}/><span>{text}</span></div> : null; }

function NewInvoice({ created, ready }: {created: (id: string) => Promise<void>; ready: boolean|null}) {
  const [link,setLink] = useState('');
  const [consent,setConsent] = useState(false);
  const [error,setError] = useState('');
  const [busy,setBusy] = useState(false);
  async function submit(event: FormEvent) {
    event.preventDefault();setError('');
    if(!ready||!consent)return;
    let id='';
    try{const url=new URL(link.trim());if(url.origin!=='https://ovxan.github.io'||url.pathname!=='/second-life/')throw new Error();id=url.searchParams.get('item')||'';}catch{setError('Gunakan tautan barang dari tombol Salin info pada detail barang Second Life.');return;}
    if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(id)){setError('Tautan belum memuat ID barang yang valid. Salin tautan dari detail barang.');return;}
    setBusy(true);try{await created(await createFeeInvoice(id));setLink('');setConsent(false);}catch(e){setError(message(e));}finally{setBusy(false);}
  }
  return <details className="fee-settings fee-new-invoice"><summary><span><ReceiptText size={19}/> Buat tagihan dari tautan barang</span><b>Rp5.000</b></summary><form className="fee-form" onSubmit={submit}><p>Gunakan tautan dari Salin info atau pesan WhatsApp barang, termasuk jika penjual sudah menandainya Terjual. Harga barang dibayar langsung ke penjual.</p><label>Tautan barang<input required type="url" value={link} onChange={e=>setLink(e.target.value)} placeholder="Tautan Second Life yang memuat ?item=…"/></label><label className="fee-checkbox"><input type="checkbox" required checked={consent} onChange={e=>setConsent(e.target.checked)}/><span>Saya sudah menyelesaikan jual beli barang ini dan setuju membayar biaya admin Rp5.000 secara terpisah ke pengelola.</span></label>{ready===false&&<p className="fee-notice">Pengelola belum mengaktifkan tujuan transfer. Tagihan baru belum dapat dibuat.</p>}<Alert text={error}/><button className="button primary" type="submit" disabled={busy||!ready||!consent}>{busy&&<LoaderCircle className="spin" size={17}/>} Buat tagihan admin Rp5.000</button></form></details>;
}

export function FeeCheckout({ item, created, login }: {item: Listing; created: (id: string) => void; login: () => void}) {
  const [ready,setReady] = useState<boolean|null>(null);
  const [error,setError] = useState('');
  const [consent,setConsent] = useState(false);
  const [busy,setBusy] = useState(false);
  useEffect(()=>{let active=true; paymentReady().then(value=>{if(active)setReady(value);}).catch(e=>{if(active)setError(message(e));});return()=>{active=false;};},[]);
  async function submit(event: FormEvent) {
    event.preventDefault(); if(!consent || !ready) return;
    setBusy(true);setError('');
    try { created(await createFeeInvoice(item.id)); } catch(e) { setError(message(e)); } finally { setBusy(false); }
  }
  return <form className="fee-checkout" onSubmit={submit}>
    <div className="fee-intro"><ReceiptText size={27}/><div><span className="eyebrow">SETELAH JUAL BELI BERHASIL</span><h3>Bayar biaya admin</h3></div></div>
    <p>Harga barang dibayar langsung kepada penjual. Selesaikan dan periksa barangnya terlebih dahulu, lalu bayar biaya admin kepada pengelola Second Life.</p>
    <dl className="fee-amounts"><div><dt>Harga pada iklan · ke penjual</dt><dd>{money(item.price)}</dd></div><div><dt>Biaya admin · ke pengelola</dt><dd>{money(ADMIN_FEE)}</dd></div><div className="fee-total"><dt>Total barang + admin</dt><dd>{money(item.price+ADMIN_FEE)}</dd></div></dl>
    <p>Tagihan yang dibuat di sini sebesar <strong>{money(ADMIN_FEE)}</strong>. Tujuan transfer akan tercantum pada tagihan. Bukti diperiksa secara manual oleh pengelola.</p>
    {ready === false && <div className="fee-notice" role="status">Pengelola belum mengatur tujuan transfer. Pembuatan tagihan akan tersedia setelah penagihan diaktifkan.</div>}
    <label className="fee-checkbox"><input type="checkbox" required checked={consent} onChange={e=>setConsent(e.target.checked)}/><span>Saya sudah menyelesaikan jual beli barang ini dengan penjual dan memahami bahwa biaya admin {money(ADMIN_FEE)} dibayar terpisah.</span></label>
    <Alert text={error}/>
    <button className="button primary full" disabled={busy || ready !== true || !consent} type="submit">{busy ? <LoaderCircle size={17} className="spin"/> : <ReceiptText size={17}/>} {busy ? 'Membuat tagihan…' : 'Buat tagihan admin Rp5.000'}</button>
    <button type="button" className="text-button" onClick={login}>Masuk / daftar akun pembeli <ArrowUpRight size={15}/></button>
    <small>Tagihan mencatat biaya admin. Harga barang dan status penyerahan barang disepakati langsung dengan penjual.</small>
  </form>;
}

function RecipientForm({ initial, saved }: {initial: PaymentSettings;saved: () => Promise<void>}) {
  const [fields,setFields] = useState(initial);
  const [busy,setBusy] = useState(false);
  const [error,setError] = useState('');
  const [success,setSuccess] = useState('');
  const change = (key: keyof PaymentSettings,value: string|boolean) => {setFields(old=>({...old,[key]:value}));setSuccess('');};
  async function submit(event: FormEvent) {event.preventDefault();setBusy(true);setError('');setSuccess('');try{await savePaymentSettings(fields);await saved();setSuccess('Tujuan pembayaran tersimpan. Pengaturan ini digunakan untuk tagihan baru.');}catch(e){setError(message(e));}finally{setBusy(false);}}
  return <details className="fee-settings" open={!initial.enabled}><summary><span><ShieldCheck size={19}/> Tujuan transfer biaya admin</span><b>{initial.enabled?'Aktif':'Belum aktif'}</b></summary><form onSubmit={submit} className="fee-form">
    <p>Isi tujuan pembayaran milik pengelola. Data ini ditampilkan kepada pembeli pada tagihannya. Tagihan lama menyimpan tujuan transfer saat tagihan dibuat.</p>
    <div className="fee-fields"><label>Jenis tujuan<select value={fields.channel} onChange={e=>change('channel',e.target.value)}><option value="bank">Rekening bank</option><option value="ewallet">E-wallet</option></select></label><label>Nama bank / e-wallet<input required={fields.enabled} maxLength={70} minLength={2} value={fields.provider} onChange={e=>change('provider',e.target.value)} placeholder="Nama bank atau e-wallet"/></label><label>Nomor rekening / telepon<input required={fields.enabled} minLength={5} maxLength={50} value={fields.account_number} onChange={e=>change('account_number',e.target.value)} placeholder="Nomor tujuan transfer"/></label><label>Nama penerima<input required={fields.enabled} minLength={2} maxLength={100} value={fields.account_name} onChange={e=>change('account_name',e.target.value)} placeholder="Nama sesuai rekening / e-wallet"/></label></div>
    <label>Petunjuk transfer<textarea rows={3} maxLength={700} value={fields.instructions} onChange={e=>change('instructions',e.target.value)} placeholder="Contoh: cantumkan nomor tagihan pada berita transfer."/></label>
    <label className="fee-checkbox"><input type="checkbox" checked={fields.enabled} onChange={e=>change('enabled',e.target.checked)}/><span>Aktifkan penagihan manual Rp5.000 ke tujuan ini.</span></label>
    <Alert text={error}/>{success&&<p className="fee-success" role="status">{success}</p>}
    <button className="button primary" disabled={busy} type="submit">{busy&&<LoaderCircle size={17} className="spin"/>} Simpan tujuan pembayaran</button>
  </form></details>;
}

function InvoiceDetail({ invoice, asAdmin, updated }: {invoice: FeeInvoice;asAdmin: boolean;updated: () => Promise<void>}) {
  const [history,setHistory] = useState<FeeEvent[]>([]);
  const [error,setError] = useState('');
  const [busy,setBusy] = useState(false);
  const [file,setFile] = useState<File|null>(null);
  const [note,setNote] = useState('');
  const [review,setReview] = useState('');
  const [received,setReceived] = useState(false);
  const [cancelling,setCancelling] = useState(false);
  const [cancelNote,setCancelNote] = useState('');
  const [proof,setProof] = useState('');
  const loadHistory=useCallback(async()=>{try{setHistory(await feeHistory(invoice.id,asAdmin));}catch(e){setError(message(e));}},[invoice.id,asAdmin]);
  useEffect(()=>{void loadHistory();setProof('');setReceived(false);},[loadHistory,invoice.status,invoice.receipt_path]);
  async function action(fn: () => Promise<void>) {setBusy(true);setError('');try{await fn();setFile(null);setCancelling(false);setReceived(false);await updated();await loadHistory();}catch(e){setError(message(e));}finally{setBusy(false);}}
  const canPay=invoice.status==='unpaid'||invoice.status==='rejected';
  return <div className="fee-invoice-detail">
    <div className="fee-invoice-title"><div><span className="eyebrow">{invoiceCode(invoice.number)}</span><h3>{invoice.title}</h3><small>Dibuat {date(invoice.created_at)}</small></div><div className="fee-due"><small>Biaya admin</small><strong>{money(invoice.fee_amount)}</strong></div></div>
    <dl className="fee-amounts"><div><dt>Harga pada iklan · bagian penjual</dt><dd>{money(invoice.item_price)}</dd></div><div><dt>Admin · tagihan ini</dt><dd>{money(invoice.fee_amount)}</dd></div><div className="fee-total"><dt>Total barang + admin</dt><dd>{money(invoice.item_price+invoice.fee_amount)}</dd></div></dl>
    <p className="fee-small">Harga barang dibayar langsung ke penjual. Penjual menerima harga barang penuh. Status di bawah hanya menunjukkan pembayaran biaya admin kepada pengelola.</p>
    {invoice.status!=='cancelled'&&<section className="fee-recipient"><h4>{!asAdmin&&canPay?'Transfer biaya admin '+money(invoice.fee_amount):'Tujuan transfer pada tagihan'}</h4><dl><div><dt>{invoice.channel==='bank'?'Bank':'E-wallet'}</dt><dd>{invoice.provider}</dd></div><div><dt>Nomor tujuan</dt><dd className="fee-account-number">{invoice.account_number}</dd></div><div><dt>Atas nama</dt><dd>{invoice.account_name}</dd></div><div><dt>Nomor tagihan</dt><dd>{invoiceCode(invoice.number)}</dd></div></dl>{invoice.instructions&&<p>{invoice.instructions}</p>}<small>Gunakan tujuan yang tercantum pada tagihan ini.</small></section>}
    {invoice.status==='submitted'&&<p className="fee-notice" role="status">Bukti sudah dikirim. Pengelola akan memeriksa penerimaan transfer sebelum menetapkan status Lunas.</p>}
    {invoice.status==='paid'&&<p className="fee-success"><CheckCircle2 size={18}/> Biaya admin terkonfirmasi lunas{invoice.paid_at?' pada '+date(invoice.paid_at):''}.</p>}
    {invoice.review_note&&<p className={invoice.status==='rejected'?'fee-notice':'fee-small'}><strong>Catatan pengelola:</strong> {invoice.review_note}</p>}
    {invoice.status==='rejected'&&!asAdmin&&<p className="fee-small">Jika sudah transfer, perbaiki bukti atau konfirmasikan ke pengelola sebelum melakukan transfer ulang.</p>}
    {invoice.buyer_note&&<p className="fee-small"><strong>Keterangan transfer:</strong> {invoice.buyer_note}</p>}
    {invoice.receipt_path&&<div className="fee-proof"><button className="button secondary" type="button" disabled={busy} onClick={()=>{setBusy(true);setError('');feeProofUrl(invoice.receipt_path,asAdmin).then(setProof).catch(e=>setError(message(e))).finally(()=>setBusy(false));}}>Lihat bukti transfer</button>{proof&&<div><img src={proof} alt={'Bukti transfer '+invoiceCode(invoice.number)} referrerPolicy="no-referrer"/><small>Akses gambar berlaku 60 detik. Tekan Lihat bukti transfer untuk membukanya lagi.</small></div>}</div>}
    {!asAdmin&&canPay&&<form className="fee-form fee-upload" onSubmit={event=>{event.preventDefault();if(file)void action(()=>submitFeeProof(invoice.id,file,note));}}><h4>Sudah transfer? Kirim bukti pembayaran</h4><label>Nama pengirim / keterangan transfer<input required minLength={3} maxLength={300} value={note} onChange={e=>setNote(e.target.value)} placeholder="Nama pengirim sesuai bukti transfer"/></label><label>Bukti transfer · JPG, PNG, atau WebP, maksimal 2 MB<input required type="file" accept="image/jpeg,image/png,image/webp" onChange={e=>{const chosen=e.target.files?.[0]||null;setFile(null);if(chosen&&chosen.size>2*1024*1024){setError('Ukuran bukti transfer maksimal 2 MB.');return;}setError('');setFile(chosen);}}/></label><p className="fee-small">Unggah bukti yang menampilkan nominal, tujuan, dan waktu transfer. Bukti hanya dapat dilihat pembeli terkait dan admin pemilik web.</p><button className="button primary" disabled={busy||!file} type="submit">{busy?<LoaderCircle className="spin" size={17}/>:<Upload size={17}/>} Kirim bukti untuk diperiksa</button></form>}
    {asAdmin&&invoice.status==='submitted'&&<form className="fee-form fee-review" onSubmit={event=>{event.preventDefault();if(received)void action(()=>reviewFeeProof(invoice.id,true,review));}}><h4>Verifikasi penerimaan biaya admin</h4><p>Cocokkan nominal, tujuan, pengirim, dan waktu transfer dengan mutasi rekening/e-wallet penerima.</p><label>Catatan verifikasi / alasan perbaikan<textarea maxLength={300} rows={2} value={review} onChange={e=>setReview(e.target.value)} placeholder="Alasan wajib diisi jika meminta perbaikan bukti."/></label><label className="fee-checkbox"><input type="checkbox" checked={received} onChange={e=>setReceived(e.target.checked)}/><span>Saya sudah memeriksa rekening/e-wallet dan menerima biaya admin {money(invoice.fee_amount)} untuk tagihan ini.</span></label><div className="fee-actions"><button type="submit" className="button primary" disabled={busy||!received}>Konfirmasi lunas</button><button type="button" className="button secondary" disabled={busy||review.trim().length<3} onClick={()=>void action(()=>reviewFeeProof(invoice.id,false,review))}>Minta perbaikan bukti</button></div></form>}
    {canPay&&<div className="fee-cancel">{!cancelling?<button type="button" className="text-button" onClick={()=>setCancelling(true)}>Batalkan tagihan</button>:<form className="fee-form" onSubmit={event=>{event.preventDefault();void action(()=>cancelFeeInvoice(invoice.id,cancelNote,asAdmin));}}><p>Batalkan jika belum ada transfer masuk. Transfer yang sudah dilakukan perlu diperiksa pengelola terlebih dahulu.</p><label>Alasan pembatalan<input required minLength={3} maxLength={300} value={cancelNote} onChange={e=>setCancelNote(e.target.value)}/></label><div className="fee-actions"><button className="button secondary" type="button" onClick={()=>setCancelling(false)}>Kembali</button><button className="button destructive" type="submit" disabled={busy}>Konfirmasi pembatalan</button></div></form>}</div>}
    <Alert text={error}/>
    <details className="fee-history"><summary>Riwayat tagihan ({history.length})</summary><ol>{history.map(event=><li key={event.id}><strong>{eventLabels[event.event]||event.event}</strong><small>{date(event.created_at)}</small><p>{event.note}</p>{asAdmin&&event.receipt_path&&event.receipt_path!==invoice.receipt_path&&<button className="text-button" type="button" disabled={busy} onClick={()=>{setBusy(true);feeProofUrl(event.receipt_path,true).then(setProof).catch(e=>setError(message(e))).finally(()=>setBusy(false));}}>Lihat bukti sebelumnya</button>}</li>)}</ol></details>
  </div>;
}

export function BillingWorkspace({ asAdmin=false, initialInvoice='', back }: {asAdmin?: boolean;initialInvoice?: string;back: () => void}) {
  const [invoices,setInvoices] = useState<FeeInvoice[]>([]);
  const [settings,setSettings] = useState<PaymentSettings|null>(null);
  const [summary,setSummary] = useState<FeeSummary|null>(null);
  const [selected,setSelected] = useState(initialInvoice);
  const [filter,setFilter] = useState('all');
  const [query,setQuery] = useState('');
  const [error,setError] = useState('');
  const [loading,setLoading] = useState(true);
  const [ready,setReady] = useState<boolean|null>(null);
  const load=useCallback(async()=>{setError('');setLoading(true);try{const data=await billingData(asAdmin);setInvoices(data.invoices);setSettings(data.settings);setSummary(data.summary);setReady(data.ready);}catch(e){setError(message(e));}finally{setLoading(false);}},[asAdmin]);
  useEffect(()=>{void load();},[load]);
  const visible=invoices.filter(invoice=>(filter==='all'||invoice.status===filter)&&`${invoiceCode(invoice.number)} ${invoice.title}`.toLowerCase().includes(query.toLowerCase()));
  const active=invoices.find(invoice=>invoice.id===selected);
  return <section className="container billing-page"><button type="button" className="back-link" onClick={back}><ArrowLeft size={15}/> {asAdmin?'Kembali ke dashboard admin':'Kembali menjelajah'}</button>
    <div className="billing-heading"><div><span className="eyebrow">{asAdmin?'RUANG PEMILIK SECOND LIFE':'PEMBAYARAN SECOND LIFE'}</span><h1>{asAdmin?'Penagihan & pendapatan':'Tagihan saya'}</h1><p>{asAdmin?'Atur tujuan transfer, periksa bukti, dan pantau penerimaan biaya admin.':'Bayar biaya admin setelah jual beli berhasil dan pantau hasil verifikasinya.'}</p></div><button type="button" className="button secondary" disabled={loading} onClick={()=>void load()}><RefreshCw size={16} className={loading?'spin':''}/> Perbarui</button></div>
    {asAdmin&&<div className="fee-summary">{[{label:'Diterima · terverifikasi',value:summary?.paid,help:summary?`${summary.paid_count} tagihan lunas`:'Memuat rekap…'},{label:'Menunggu verifikasi',value:summary?.submitted,help:'Bukti dikirim pembeli'},{label:'Belum lunas',value:summary?.unpaid,help:'Termasuk bukti perlu perbaikan'}].map(card=><div key={card.label}><span>{card.label}</span><strong>{card.value===undefined?'—':money(card.value)}</strong><small>{card.help}</small></div>)}</div>}
    {asAdmin&&settings&&<RecipientForm initial={settings} saved={load}/>}
    {!asAdmin&&<NewInvoice ready={ready} created={async id=>{await load();setSelected(id);setFilter('all');setQuery('');}}/>}
    <div className="fee-notice"><Info size={18}/><p>{asAdmin?'Pendapatan adalah penerimaan biaya admin yang sudah Anda konfirmasi. Harga barang dibayar langsung ke penjual; tagihan dibatalkan tidak dihitung sebagai pendapatan.':'Harga barang dibayar langsung ke penjual. Biaya admin Rp5.000 dibayar terpisah ke tujuan pada tagihan. Donasi dan informasi jasa reparasi tetap tanpa biaya admin platform.'}</p></div>
    <Alert text={error}/>
    <div className="fee-toolbar"><label>Cari tagihan<input placeholder="Nomor tagihan atau nama barang" value={query} onChange={e=>setQuery(e.target.value)}/></label><label>Status<select value={filter} onChange={e=>setFilter(e.target.value)}><option value="all">Semua status</option>{Object.entries(feeStatusLabels).map(([key,label])=><option key={key} value={key}>{label}</option>)}</select></label></div>
    <div className="fee-workspace"><div className="fee-invoice-list">{!loading&&!error&&!visible.length&&<div className="fee-empty"><ReceiptText size={34}/><h3>{invoices.length?'Tidak ada hasil yang sesuai.':'Belum ada tagihan.'}</h3><p>{asAdmin?'Tagihan pembeli akan muncul di sini setelah penagihan diaktifkan.':'Setelah jual beli berhasil, buka detail barang dan pilih Bayar biaya admin.'}</p></div>}{visible.map(invoice=><button key={invoice.id} type="button" className={'fee-invoice-row '+(selected===invoice.id?'selected':'')} onClick={()=>setSelected(invoice.id)}><span><small>{invoiceCode(invoice.number)}</small><strong>{invoice.title}</strong><time>{date(invoice.created_at)}</time></span><span><b>{money(invoice.fee_amount)}</b><small className={'fee-status '+invoice.status}>{feeStatusLabels[invoice.status]}</small></span></button>)}{loading&&<p role="status">Memuat tagihan…</p>}{invoices.length===100&&<p className="fee-small">Menampilkan 100 tagihan terbaru. Rekap admin mencakup seluruh tagihan.</p>}</div><div className="fee-detail-panel">{active?<InvoiceDetail key={active.id} invoice={active} asAdmin={asAdmin} updated={load}/>:<div className="fee-empty"><ReceiptText size={33}/><h3>Pilih tagihan untuk melihat rinciannya.</h3><p>Tujuan transfer, bukti, status, dan riwayat pembayaran ditampilkan di sini.</p></div>}</div></div>
  </section>;
}
