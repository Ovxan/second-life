import { memberClient, requireMember } from './member-auth';
import { requireSiteAdmin } from './admin-auth';
import { imageBlob } from './online-api';

const bucket='second-life-campus-documents';
export type CampusStatus='draft'|'pending'|'approved'|'rejected'|'withdrawn'|'revoked';
export type CampusRequest={
  id:string;user_id:string;full_name:string;campus:string;document_kind:'ktm'|'alumni';document_path:string;
  status:CampusStatus;created_at:string;submitted_at:string|null;reviewed_at:string|null;
  review_note:string;revoke_note:string;document_deleted_at:string|null;
};
export const campusStatusLabels:Record<CampusStatus,string>={draft:'Belum terkirim',pending:'Menunggu pemeriksaan',approved:'Disetujui',rejected:'Perlu perbaikan',withdrawn:'Ditarik',revoked:'Persetujuan dicabut'};
function checked(error:{message?:string;code?:string}|null){
  if(!error)return;
  if(error.code==='P0001')throw new Error(error.message);
  if(error.code==='42501')throw new Error('Akses dokumen tidak diizinkan. Login dengan akun pengaju atau pemilik web.');
  if(/network|fetch/i.test(error.message||''))throw new Error('Koneksi terputus. Periksa internet lalu perbarui status pengajuan.');
  throw new Error('Dokumen belum dapat diproses. Perbarui halaman dan coba kembali.');
}
export async function campusRequests(asAdmin=false,status='all'):Promise<CampusRequest[]>{
  const connection=asAdmin?(await requireSiteAdmin()).connection:memberClient();
  const user=asAdmin?null:await requireMember();
  let query=connection.from('campus_verifications').select('*').order('created_at',{ascending:false}).limit(asAdmin?200:50);
  if(user)query=query.eq('user_id',user.id);
  if(asAdmin&&status!=='all')query=query.eq('status',status);
  const result=await query;checked(result.error);return result.data||[];
}
export async function removeCampusDocument(request:CampusRequest,asAdmin=false){
  const connection=asAdmin?(await requireSiteAdmin()).connection:memberClient();
  if(!asAdmin)await requireMember();
  const removed=await connection.storage.from(bucket).remove([request.document_path]);checked(removed.error);
  const marked=await connection.rpc('mark_campus_document_deleted',{p_request_id:request.id});checked(marked.error);
}
export async function submitCampusDocument(input:{name:string;campus:string;kind:'ktm'|'alumni';consent:boolean;file:File}){
  const user=await requireMember();
  if(!input.consent)throw new Error('Baca dan setujui penggunaan dokumen terlebih dahulu.');
  const photo=await imageBlob(input.file); // Decode and re-encode, removing source image metadata.
  const connection=memberClient();
  const started=await connection.rpc('start_campus_verification',{p_full_name:input.name.trim(),p_campus:input.campus.trim(),p_document_kind:input.kind,p_consent:input.consent});
  checked(started.error);const id=String(started.data);const path=user.id+'/'+id+'.jpg';
  try{
    const uploaded=await connection.storage.from(bucket).upload(path,photo,{contentType:'image/jpeg',upsert:false,cacheControl:'0'});checked(uploaded.error);
    const sent=await connection.rpc('submit_campus_verification',{p_request_id:id});checked(sent.error);
  }catch(error){
    // A network error can occur after commit. Read the authoritative state before
    // cleaning up; never withdraw an already submitted or reviewed request.
    const state=await connection.from('campus_verifications').select('status').eq('id',id).maybeSingle();
    if(!state.error&&state.data?.status==='pending')return;
    if(!state.error&&state.data?.status==='draft'){
      const withdrawn=await connection.rpc('withdraw_campus_verification',{p_request_id:id});
      if(!withdrawn.error)await removeCampusDocument({id,document_path:path} as CampusRequest).catch(()=>{});
    }
    throw error;
  }
}
export async function withdrawCampusRequest(request:CampusRequest){
  await requireMember();const result=await memberClient().rpc('withdraw_campus_verification',{p_request_id:request.id});checked(result.error);
  try{await removeCampusDocument(request);return '';}catch{return 'Pengajuan sudah ditarik. Foto masih menunggu penghapusan; gunakan tombol Hapus foto dokumen untuk mencoba kembali.';}
}
export async function reviewCampusRequest(request:CampusRequest,approved:boolean,note:string){
  const {connection}=await requireSiteAdmin();
  const result=await connection.rpc('review_campus_verification',{p_request_id:request.id,p_approved:approved,p_note:note.trim()});checked(result.error);
  try{await removeCampusDocument(request,true);return '';}catch{return 'Keputusan tersimpan. Foto masih menunggu penghapusan; coba kembali melalui Hapus foto dokumen.';}
}
export async function revokeCampusRequest(id:string,note:string){
  const {connection}=await requireSiteAdmin();const result=await connection.rpc('revoke_campus_verification',{p_request_id:id,p_note:note.trim()});checked(result.error);
}
export async function campusDocumentUrl(request:CampusRequest,asAdmin=false){
  const connection=asAdmin?(await requireSiteAdmin()).connection:memberClient();if(!asAdmin)await requireMember();
  const result=await connection.storage.from(bucket).createSignedUrl(request.document_path,60);checked(result.error);return result.data!.signedUrl;
}
export function subscribeCampus(callback:()=>void){
  const refresh=()=>{if(document.visibilityState==='visible')callback();};
  const timer=setInterval(refresh,45000);window.addEventListener('focus',refresh);document.addEventListener('visibilitychange',refresh);
  return()=>{clearInterval(timer);window.removeEventListener('focus',refresh);document.removeEventListener('visibilitychange',refresh);};
}
