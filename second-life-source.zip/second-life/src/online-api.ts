import config from './backend-config.json';
import { pricingText } from './lib/pricing';
import { adminAccess, requireSiteAdmin, adminClient } from './admin-auth';
import { memberClient, currentMember, requireMember } from './member-auth';
import { categories, conditions, statuses, type Listing, type Kind } from './lib/types';
const bucket = 'second-life-photos';
const columns = 'id,owner_id,kind,title,category,description,condition,location,price,photo_path,seller_name,phone,status,created_at';
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
export function databaseConfigured() { return !!config.url && !!config.publishableKey; }
function db() { return memberClient(); }
function errorMessage(error: { message?: string; code?: string; status?: number } | null): string {
  const message = error?.message || '';
  if (/anonymous.*disabled|anonymous_provider_disabled/i.test(message + error?.code)) return 'Akses pemasangan barang belum diaktifkan. Pengelola perlu mengaktifkan sesi pengunjung pada database.';
  if (/rate.limit|too many|429/i.test(message + error?.code)) return 'Terlalu banyak percobaan. Coba lagi beberapa saat lagi.';
  if (error?.code === '42501' || /row.level|permission denied/i.test(message)) return 'Perubahan tidak diizinkan. Login dengan akun pemilik iklan atau admin web.';
  if (error?.code === '23514') return 'Informasi barang belum sesuai. Periksa harga, kondisi, foto, dan status iklan.';
  if (error?.code === 'P0001') return message;
  if (/fetch|network|connection/i.test(message)) return 'Koneksi ke database terputus. Periksa internet lalu coba lagi.';
  return 'Data belum dapat diproses. Silakan coba lagi beberapa saat lagi.';
}
function checked(error: { message?: string; code?: string; status?: number } | null) { if (error) throw new Error(errorMessage(error)); }
async function writer() { return requireMember(); }
function demoFavorites(): string[] {
  try { const value = JSON.parse(localStorage.getItem('sl-demo-favorites') || '[]'); return Array.isArray(value) ? value.filter(x => typeof x === 'string' && x.startsWith('demo-')) : []; } catch { return []; }
}
function saveDemoFavorite(id: string, saved: boolean) {
  const values = demoFavorites(); const next = saved ? [...new Set([...values, id])] : values.filter(x => x !== id);
  try { localStorage.setItem('sl-demo-favorites', JSON.stringify(next)); } catch { throw new Error('Browser belum mengizinkan penyimpanan favorit contoh.'); }
}
function normalized(input: Record<string, unknown>) {
  const text = (key: string) => String(input[key] ?? '').trim();
  const kind = input.kind as Kind;
  if (!['jual','donasi','jasa'].includes(kind)) throw new Error('Pilih jenis iklan yang tersedia.');
  if (text('title').length < 5 || text('title').length > 100) throw new Error('Nama barang atau jasa harus berisi 5–100 karakter.');
  if (!categories.slice(1).includes(text('category'))) throw new Error('Pilih kategori yang tersedia.');
  if (!conditions.includes(text('condition'))) throw new Error('Pilih kondisi yang tersedia.');
  if (text('description').length < 20 || text('description').length > 3000) throw new Error('Deskripsi harus berisi 20–3.000 karakter.');
  if (text('location').length < 3 || text('location').length > 120) throw new Error('Isi lokasi atau area layanan dengan jelas.');
  if (text('sellerName').length < 2 || text('sellerName').length > 70) throw new Error('Isi nama pemilik atau pengelola.');
  let phone = text('phone').replace(/[\s()+-]/g, ''); if (phone.startsWith('0')) phone = '62' + phone.slice(1);
  if (!/^628[0-9]{7,11}$/.test(phone)) throw new Error('Masukkan nomor WhatsApp Indonesia yang valid.');
  const price = kind === 'jual' ? Number(input.price) : 0;
  if (!Number.isInteger(price) || price < (kind === 'jual' ? 1000 : 0) || price > 100000000) throw new Error('Harga jual minimal Rp1.000 dan maksimal Rp100.000.000.');
  return { kind, title: text('title'), category: text('category'), condition: text('condition'), description: text('description'), location: text('location'), seller_name: text('sellerName'), phone, price };
}
function photoPath(url: unknown, owner: string) {
  if (!url) return '';
  const prefix = config.url.replace(/\/$/, '') + '/storage/v1/object/public/' + bucket + '/';
  if (typeof url !== 'string' || !url.startsWith(prefix)) throw new Error('Unggah foto melalui formulir barang.');
  const value = decodeURIComponent(url.slice(prefix.length));
  const parts = value.split('/');
  if (parts.length !== 2 || parts[0] !== owner || !/^[0-9a-f-]{36}\.(jpg|jpeg|png|webp)$/.test(parts[1])) throw new Error('Gunakan foto milik iklanmu sendiri.');
  return value;
}
function publicItem(row: Record<string, any>, owner?: string, siteAdmin?: boolean, canPost = false): Listing {
  return { id: row.id, kind: row.kind, title: row.title, category: row.category, description: row.description, condition: row.condition, location: row.location, price: Number(row.price), photo: row.photo_path ? db().storage.from(bucket).getPublicUrl(row.photo_path).data.publicUrl : '', sellerName: row.seller_name, phone: row.phone, status: row.status, createdAt: Date.parse(row.created_at), mine: row.kind !== 'jasa' && row.owner_id === owner, canManage: siteAdmin === true || (canPost && row.kind !== 'jasa' && row.owner_id === owner), demo: false };
}
export async function imageBlob(file: Blob): Promise<Blob> {
  if (!file.size || file.size > 2 * 1024 * 1024) throw new Error('Ukuran foto maksimal 2 MB.');
  if (!['image/jpeg','image/png','image/webp'].includes(file.type)) throw new Error('Gunakan foto JPG, PNG, atau WebP.');
  const url = URL.createObjectURL(file);
  try {
    const image = await new Promise<HTMLImageElement>((resolve, reject) => { const im = new Image(); im.onload=()=>resolve(im); im.onerror=()=>reject(new Error('Foto belum dapat dibaca. Pilih foto lain.')); im.src=url; });
    const ratio = Math.min(1, 1280/Math.max(image.naturalWidth,image.naturalHeight));
    const canvas = document.createElement('canvas'); canvas.width=Math.max(1,Math.round(image.naturalWidth*ratio)); canvas.height=Math.max(1,Math.round(image.naturalHeight*ratio));
    const ctx=canvas.getContext('2d'); if (!ctx) throw new Error('Browser belum mendukung pengolahan foto.');
    ctx.fillStyle='#ffffff'; ctx.fillRect(0,0,canvas.width,canvas.height); ctx.drawImage(image,0,0,canvas.width,canvas.height);
    return await new Promise<Blob>((resolve,reject)=>canvas.toBlob(value=>value?resolve(value):reject(new Error('Foto belum dapat diproses.')), 'image/jpeg', .82));
  } finally { URL.revokeObjectURL(url); }
}
async function removeUnusedPhoto(path: string, owner: string, connection = db(), asAdmin = false) {
  if (!path || (!asAdmin && path.split('/')[0] !== owner)) return;
  const { count, error } = await connection.from('listings').select('id',{count:'exact',head:true}).eq('photo_path',path);
  if (!error && count===0) await connection.storage.from(bucket).remove([path]);
}
export async function api<T = Record<string, unknown>>(url: string, init?: RequestInit): Promise<T> {
  const method = init?.method || 'GET'; let connection = db();
  if (url === '/api/items' && method === 'GET') {
    const [{ data: auth, error: sessionError }, admin, member] = await Promise.all([connection.auth.getSession(), adminAccess(), currentMember()]); checked(sessionError);
    const owner=auth.session?.user.id;
    const requests = [connection.from('listings').select(columns).order('created_at',{ascending:false}).limit(1000)];
    if (owner) requests.push(connection.from('listings').select(columns).eq('owner_id',owner).order('created_at',{ascending:false}).limit(100));
    if (admin.isAdmin && admin.userId) requests.push(adminClient().from('listings').select(columns).order('created_at',{ascending:false}).limit(1000));
    const results = await Promise.all(requests); for (const result of results) checked(result.error);
    const merged = new Map<string, any>(); for (const result of results) for (const row of result.data || []) merged.set(row.id,row);
    let saved: string[]=[];
    if (owner) { const {data,error}=await connection.from('favorites').select('listing_id').eq('owner_id',owner); checked(error); saved=(data||[]).map(i=>i.listing_id); }
    const items=[...merged.values()].map(row=>publicItem(row,owner,admin.isAdmin,member?.canPost));
    if(items.length){
      const reviews=await connection.rpc('public_campus_reviews',{p_listing_ids:items.slice(0,1000).map(item=>item.id)});
      if(!reviews.error){const campuses=new Map<string,string>((reviews.data||[]).map((row:{listing_id:string;campus:string})=>[row.listing_id,row.campus]));for(const item of items)item.reviewedCampus=campuses.get(item.id);}
    }
    return { items, favorites:[...saved,...demoFavorites()], user:member, admin } as T;
  }
  if (url === '/api/upload' && method === 'POST') {
    if (!(init?.body instanceof Blob)) throw new Error('Pilih foto yang akan diunggah.');
    const service = new Headers(init.headers).get('X-Second-Life-Kind') === 'jasa' || new Headers(init.headers).get('X-Second-Life-Admin') === 'true';
    const identity = service ? await requireSiteAdmin() : { connection, userId: (await writer()).id };
    connection = identity.connection;
    const file=await imageBlob(init.body); const path=identity.userId+'/'+crypto.randomUUID()+'.jpg';
    const {error}=await connection.storage.from(bucket).upload(path,file,{contentType:'image/jpeg',upsert:false,cacheControl:'3600'}); checked(error);
    return {url:connection.storage.from(bucket).getPublicUrl(path).data.publicUrl} as T;
  }
  const body = typeof init?.body === 'string' ? JSON.parse(init.body) : {};
  if (url === '/api/favorites' && method === 'POST' && typeof body.id==='string' && body.id.startsWith('demo-')) {
    if (typeof body.saved !== 'boolean') throw new Error('Data favorit tidak sesuai.'); saveDemoFavorite(body.id,body.saved); return {ok:true} as T;
  }
  let user: { id: string }; let actingAdmin = false;
  const administrative = (url === '/api/items' && method === 'POST' && (body.kind === 'jasa' || body.asAdmin === true));
  const moderation = url.startsWith('/api/items/') ? await adminAccess() : null;
  if (administrative || moderation?.isAdmin) { const admin = await requireSiteAdmin(); connection = admin.connection; user = { id: admin.userId }; actingAdmin = true; }
  else user = await writer();
  if (url === '/api/items' && method === 'POST') {
    if(!actingAdmin){const member=await requireMember();if(!member.canPublish)throw new Error('Ajukan KTM atau bukti alumni dan tunggu persetujuan admin sebelum memasang barang baru.');}
    const fields=normalized(body); const path=photoPath(body.photo,user.id);
    if (fields.kind!=='jasa' && !path) throw new Error('Tambahkan foto barang.');
    const sourceId=typeof body.sourceId==='string' ? body.sourceId.slice(0,64) : null;
    const {data,error}=await connection.from('listings').insert({...fields,photo_path:path,source_id:sourceId}).select('id').single();
    if (error?.code==='23505' && sourceId) { const existing=await connection.from('listings').select('id').eq('owner_id',user.id).eq('source_id',sourceId).maybeSingle(); checked(existing.error); if(existing.data) return {id:existing.data.id} as T; }
    checked(error); return {id:data!.id} as T;
  }
  if (url === '/api/favorites' && method === 'POST') {
    if (typeof body.id!=='string'||!uuid.test(body.id)||typeof body.saved!=='boolean') throw new Error('Data favorit tidak sesuai.');
    const result=body.saved ? await connection.from('favorites').upsert({listing_id:body.id},{onConflict:'owner_id,listing_id',ignoreDuplicates:true}) : await connection.from('favorites').delete().eq('owner_id',user.id).eq('listing_id',body.id);
    checked(result.error); return {ok:true} as T;
  }
  if (url.startsWith('/api/items/')) {
    const id=url.slice('/api/items/'.length); if(!uuid.test(id)) throw new Error('Iklan tidak ditemukan.');
    const asAdmin = actingAdmin;
    let lookup = connection.from('listings').select('kind,photo_path').eq('id',id);
    if (!asAdmin) lookup = lookup.eq('owner_id',user.id);
    const found = await lookup.maybeSingle(); checked(found.error);
    if (found.data?.kind === 'jasa' && !asAdmin) throw new Error('Hanya admin pemilik web yang sudah login dapat mengubah jasa reparasi.');
    if(!found.data) throw new Error('Iklan tidak ditemukan atau akun ini tidak memiliki akses pemilik maupun admin.');
    if (method==='PATCH') {
      let update: Record<string, unknown>;
      if(Object.keys(body).length===1 && typeof body.status==='string') {
        if(!statuses(found.data.kind as Kind).includes(body.status)) throw new Error('Status tidak sesuai jenis iklan.'); update={status:body.status};
      } else {
        const fields=normalized(body); if(fields.kind!==found.data.kind) throw new Error('Jenis iklan tidak dapat diubah.');
        const {kind,...mutable}=fields; const unchangedPhoto = found.data.photo_path ? connection.storage.from(bucket).getPublicUrl(found.data.photo_path).data.publicUrl : ''; const path = body.photo === unchangedPhoto ? found.data.photo_path : photoPath(body.photo,user.id); if(kind!=='jasa'&&!path) throw new Error('Tambahkan foto barang.'); update={...mutable,photo_path:path};
      }
      let mutation = connection.from('listings').update(update).eq('id',id); if (!asAdmin) mutation = mutation.eq('owner_id',user.id); const result = await mutation.select('id'); checked(result.error);
      if(!result.data?.length) throw new Error('Iklan sudah dihapus atau tidak dapat diubah.');
      if(update.photo_path!==undefined && update.photo_path!==found.data.photo_path) await removeUnusedPhoto(found.data.photo_path,user.id,connection,asAdmin).catch(()=>{});
      return {ok:true} as T;
    }
    if(method==='DELETE') {
      let mutation = connection.from('listings').delete().eq('id',id); if (!asAdmin) mutation = mutation.eq('owner_id',user.id); const result = await mutation.select('id'); checked(result.error);
      if(!result.data?.length) throw new Error('Iklan sudah dihapus atau tidak dapat diubah.');
      await removeUnusedPhoto(found.data.photo_path,user.id,connection,asAdmin).catch(()=>{}); return {ok:true} as T;
    }
  }
  throw new Error('Fitur ini belum tersedia.');
}
export function subscribeCatalog(callback:()=>void) {
  if(!databaseConfigured()) return ()=>{};
  let timer:ReturnType<typeof setTimeout>|undefined;
  const channel=db().channel('second-life-catalog').on('postgres_changes',{event:'*',schema:'public',table:'listings'},()=>{clearTimeout(timer);timer=setTimeout(callback,600);}).subscribe();
  const refresh=()=>{if(document.visibilityState==='visible') callback();};
  // A closed listing stops passing public RLS, so its final update may not be
  // delivered to another visitor. Periodic reads also cover reconnect gaps.
  const interval=setInterval(refresh,30000);
  document.addEventListener('visibilitychange',refresh); window.addEventListener('online',refresh); window.addEventListener('focus',refresh);
  return ()=>{clearTimeout(timer);clearInterval(interval);document.removeEventListener('visibilitychange',refresh);window.removeEventListener('online',refresh);window.removeEventListener('focus',refresh);void db().removeChannel(channel);};
}
export function safeHistoryReplace(data:unknown,title:string,url:string) {try{window.history.replaceState(data,title,url);}catch{}}
export function makeListingText(item:Listing) {return `${item.title}\n${pricingText(item)}\nKondisi: ${item.condition}\nLokasi: ${item.location}\n\n${item.description}${item.phone?'\nWhatsApp: +'+item.phone:''}\n\nSecond Life${item.demo?' · Barang contoh, bukan penawaran asli.':'\nhttps://ovxan.github.io/second-life/?item='+encodeURIComponent(item.id)}`;}
export function legacyCount() {try{const data=JSON.parse(localStorage.getItem('second-life-html-v1')||'{}');return Array.isArray(data.items)?data.items.length:0;}catch{return 0;}}
export async function importLegacy() {
  const value=JSON.parse(localStorage.getItem('second-life-html-v1')||'{}'); if(!Array.isArray(value.items))return {imported:0,skipped:0,failed:0};
  const user=await writer(); let imported=0,skipped=0,failed=0;
  for(const old of value.items.slice(0,100)) {
    try {
      const sourceId=('local:'+String(old.id)).slice(0,64);
      const oldWriter=old.kind==='jasa' ? await requireSiteAdmin() : {connection:db(),userId:user.id};
      const existing=await oldWriter.connection.from('listings').select('id').eq('owner_id',oldWriter.userId).eq('source_id',sourceId).maybeSingle(); checked(existing.error);
      if(existing.data){skipped++;continue;}
      let photo='';
      if(old.photo) {
        const match=/^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(old.photo);if(!match)throw new Error('Foto lama tidak valid.');
        const bytes=Uint8Array.from(atob(match[2]),c=>c.charCodeAt(0));
        const upload=await api<{url:string}>('/api/upload',{method:'POST',headers:{'X-Second-Life-Kind':old.kind},body:new Blob([bytes],{type:match[1]})});photo=upload.url;
      }
      const added=await api<{id:string}>('/api/items',{method:'POST',body:JSON.stringify({...old,photo,sourceId})});
      if(old.status!=='Tersedia' && statuses(old.kind).includes(old.status)) await api('/api/items/'+added.id,{method:'PATCH',body:JSON.stringify({status:old.status})});
      imported++;
    } catch {failed++;}
  }
  return {imported,skipped,failed};
}
