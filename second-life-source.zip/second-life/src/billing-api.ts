import { memberClient, requireMember } from './member-auth';
import { requireSiteAdmin } from './admin-auth';
import { imageBlob } from './online-api';

export type FeeStatus = 'unpaid' | 'submitted' | 'rejected' | 'paid' | 'cancelled';
export type PaymentSettings = { enabled: boolean; channel: 'bank' | 'ewallet'; provider: string; account_name: string; account_number: string; instructions: string };
export type FeeInvoice = Omit<PaymentSettings,'enabled'> & {
  id: string; number: number; title: string; item_price: number; fee_amount: number; payer_id: string; seller_id: string; buyer_id: string | null;
  status: FeeStatus; receipt_path: string; buyer_note: string; review_note: string;
  created_at: string; submitted_at: string | null; paid_at: string | null; sale_confirmed_at: string | null;
};
export type FeeEvent = { id: number; event: string; note: string; receipt_path: string; created_at: string };
export type FeeSummary = { paid: number; submitted: number; unpaid: number; paid_count: number };
export const feeStatusLabels: Record<FeeStatus,string> = { unpaid: 'Belum dibayar', submitted: 'Menunggu verifikasi', rejected: 'Perlu perbaikan', paid: 'Lunas', cancelled: 'Dibatalkan' };
export const invoiceCode = (number: number) => 'SL-' + String(number).padStart(6,'0');
const bucket = 'second-life-receipts';
function checked(error: {code?: string; message?: string; status?: number} | null) {
  if (!error) return;
  if (error.code === 'P0001') throw new Error(error.message);
  if (error.code === '42501' || /row.level|permission denied/i.test(error.message || '')) throw new Error('Akun ini tidak memiliki akses ke data atau tindakan pembayaran tersebut.');
  if (/fetch|network/i.test(error.message || '')) throw new Error('Koneksi terputus. Periksa internet dan coba lagi.');
  if (/rate.limit/i.test(error.code || '') || error.status === 429) throw new Error('Terlalu banyak permintaan. Coba lagi beberapa saat lagi.');
  throw new Error('Data tagihan belum dapat diproses. Coba lagi atau hubungi pengelola.');
}
async function billingConnection(asAdmin = false) {
  if (asAdmin) return (await requireSiteAdmin()).connection;
  await requireMember();
  return memberClient();
}
export async function paymentReady() {
  const result = await memberClient().rpc('fee_payment_ready'); checked(result.error); return result.data === true;
}
export async function billingData(asAdmin = false) {
  const connection = await billingConnection(asAdmin);
  let invoiceQuery=connection.from('admin_fee_invoices').select('*');
  if(!asAdmin) {
    const session=await connection.auth.getSession();
    const payerId=session.data.session?.user.id;
    if(!payerId)throw new Error('Login terlebih dahulu untuk melihat tagihanmu.');
    invoiceQuery=invoiceQuery.eq('payer_id',payerId);
  }
  const invoices=await invoiceQuery.order('created_at',{ascending:false}).limit(100);
  checked(invoices.error);
  if (!asAdmin) {
    const ready = await connection.rpc('fee_payment_ready'); checked(ready.error);
    return { invoices: (invoices.data || []) as FeeInvoice[], settings: null, summary: null, ready: ready.data === true };
  }
  const [settings,summary] = await Promise.all([
    connection.from('admin_fee_settings').select('enabled,channel,provider,account_name,account_number,instructions').single(),
    connection.rpc('fee_income_summary'),
  ]);
  checked(settings.error); checked(summary.error);
  return { invoices: (invoices.data || []) as FeeInvoice[], settings: settings.data as PaymentSettings, summary: summary.data as FeeSummary, ready: settings.data?.enabled === true };
}
export async function savePaymentSettings(settings: PaymentSettings) {
  const connection = await billingConnection(true);
  const result = await connection.rpc('save_fee_payment_settings',{p_enabled:settings.enabled,p_channel:settings.channel,p_provider:settings.provider,p_account_name:settings.account_name,p_account_number:settings.account_number,p_instructions:settings.instructions}); checked(result.error);
}
export async function createFeeInvoice(listingId: string) {
  const connection = await billingConnection();
  const result = await connection.rpc('create_fee_invoice',{p_listing_id:listingId}); checked(result.error);
  return result.data as string;
}
export async function completeSale(listingId: string) {
  const connection = await billingConnection();
  const result = await connection.rpc('complete_sale',{p_listing_id:listingId}); checked(result.error);
  return result.data as string;
}
export async function submitFeeProof(invoiceId: string,file: File,note: string) {
  const buyer = await requireMember();
  const connection = memberClient();
  const image = await imageBlob(file);
  const path = `${buyer.id}/${invoiceId}/${crypto.randomUUID()}.jpg`;
  const upload = await connection.storage.from(bucket).upload(path,image,{contentType:'image/jpeg',cacheControl:'0',upsert:false}); checked(upload.error);
  const result = await connection.rpc('submit_fee_proof',{p_invoice_id:invoiceId,p_receipt_path:path,p_buyer_note:note.trim()}); checked(result.error);
}
export async function reviewFeeProof(invoiceId: string,approved: boolean,note: string) {
  const connection = await billingConnection(true);
  const result = await connection.rpc('review_fee_proof',{p_invoice_id:invoiceId,p_approved:approved,p_note:note.trim()}); checked(result.error);
}
export async function cancelFeeInvoice(invoiceId: string,note: string,asAdmin = false) {
  const connection = await billingConnection(asAdmin);
  const result = await connection.rpc('cancel_fee_invoice',{p_invoice_id:invoiceId,p_note:note.trim()}); checked(result.error);
}
export async function feeHistory(invoiceId: string,asAdmin = false) {
  const connection = await billingConnection(asAdmin);
  const result = await connection.from('admin_fee_events').select('id,event,note,receipt_path,created_at').eq('invoice_id',invoiceId).order('id',{ascending:true}); checked(result.error);
  return (result.data || []) as FeeEvent[];
}
export async function feeProofUrl(path: string,asAdmin = false) {
  const connection = await billingConnection(asAdmin);
  const result = await connection.storage.from(bucket).createSignedUrl(path,60); checked(result.error);
  return result.data!.signedUrl;
}

export function subscribeBilling(asAdmin: boolean,callback: () => void) {
  let stopped=false;
  let cleanup=()=>{};
  void billingConnection(asAdmin).then(connection=>{
    if(stopped)return;
    const channel=connection.channel('second-life-fees-'+crypto.randomUUID()).on('postgres_changes',{event:'*',schema:'public',table:'admin_fee_invoices'},callback).subscribe();
    cleanup=()=>{void connection.removeChannel(channel);};
  }).catch(()=>{});
  const refresh=()=>{if(document.visibilityState==='visible')callback();};
  const interval=setInterval(refresh,45000);
  window.addEventListener('focus',refresh);document.addEventListener('visibilitychange',refresh);
  return ()=>{stopped=true;cleanup();clearInterval(interval);window.removeEventListener('focus',refresh);document.removeEventListener('visibilitychange',refresh);};
}
