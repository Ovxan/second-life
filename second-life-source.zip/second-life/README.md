# Second Life

Marketplace sirkular untuk mahasiswa dan alumni: jual beli, donasi, dan informasi jasa reparasi.

Web publik: https://ovxan.github.io/second-life/

`index.html` adalah hasil build satu berkas. CSS, JavaScript, dan tujuh foto ilustrasi disertakan di dalam HTML. Katalog asli dan foto pengguna tersimpan di Supabase, sehingga perlu koneksi internet. GitHub Pages menerbitkan berkas ini dari branch `main`.

## Fitur

- Katalog bersama, pencarian, filter, favorit, dan pembaruan katalog secara realtime.
- Pasang barang/jasa, unggah foto maksimal 2 MB, edit, ubah status, dan hapus iklan sendiri.
- Pengunjung dapat membaca tanpa login. Saat pertama menulis, Supabase membuat sesi tamu. Hak edit tersimpan pada browser dan perangkat tersebut; menghapus data browser atau sesi privat menghilangkan akses pemilik. Belum ada pemulihan atau pemindahan akses antarperangkat.
- Nama dan WhatsApp diterbitkan setelah persetujuan pada formulir. Hubungan transaksi berlangsung langsung melalui WhatsApp. Pembayaran dan biaya layanan otomatis belum tersedia.
- Iklan berlabel “Contoh” merupakan demonstrasi, bukan penawaran asli. Favorit contoh disimpan lokal; favorit iklan asli bersifat privat dalam database sesi pemilik.
- Pengguna versi lama dapat memilih memindahkan iklan dari browser melalui Barang saya. Proses meminta persetujuan publikasi kontak dan mempertahankan salinan lama.

## Pengembangan

Gunakan Node.js 22 atau lebih baru dan pnpm.

```sh
pnpm install
pnpm exec tsc --noEmit
pnpm test
pnpm build
```

Sumber UI berada pada `src/marketplace.tsx`, akses data pada `src/online-api.ts`, dan konfigurasi publik pada `src/backend-config.json`. Build melalui `scripts/build.mjs` menghasilkan ulang `index.html`; unggah hasil tersebut bersama perubahan sumber.

## Database

Migrasi `supabase/migrations/202611020001_second_life.sql` telah diterapkan sekali pada proyek yang dikonfigurasi. Jangan menjalankannya ulang pada proyek yang sama. Untuk proyek baru yang kosong: jalankan migrasi, aktifkan anonymous sign-ins pada Supabase Auth, lalu isi URL dan **publishable key** publik pada konfigurasi. Jangan pernah menyimpan secret key, service role key, password database, atau token sesi di repository.

Row Level Security membatasi perubahan iklan dan favorit ke pemiliknya. Katalog aktif dan foto bucket `second-life-photos` bersifat publik. Validasi database membatasi isian, status, kepemilikan foto, serta 100 iklan per sesi dan 20 iklan baru per jam per sesi. Supabase juga menerapkan batas signup. Untuk trafik besar, tambahkan CAPTCHA pada alur sesi tamu dan mekanisme moderasi.

`tests/rls.mjs` menguji kebijakan PostgreSQL dan integritas melalui PGlite tanpa kredensial admin. Foto ilustrasi: Unsplash. Belum ada verifikasi identitas kampus atau moderasi admin.

Uji integrasi opsional: `RUN_LIVE_TESTS=1 node tests/live.mjs`. Ini membuat dua sesi tamu, satu iklan bertanda pengujian, dan satu foto; kemudian membersihkan iklan/foto menggunakan sesi pemilik. Tidak memerlukan secret key.
