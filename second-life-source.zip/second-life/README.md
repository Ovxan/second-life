# Second Life

Marketplace sirkular untuk mahasiswa dan alumni: jual beli, donasi, dan informasi jasa reparasi.

Web publik: https://ovxan.github.io/second-life/

index.html adalah satu berkas HTML dengan CSS, JavaScript, dan tujuh foto ilustrasi tertanam. Data dan foto pengguna memakai Supabase sehingga perlu internet. GitHub Pages menerbitkan HTML dari branch main.

## Akun pengunjung

Katalog dapat dilihat tanpa login. Untuk memasang barang/donasi, mengunggah foto, menyimpan favorit asli, atau mengubah iklan, pengguna wajib daftar, mengonfirmasi email, mengatur password, lalu login. Nama dan akun disimpan oleh Supabase Auth; password tidak disimpan sebagai teks pada HTML atau tabel publik. Pengguna terdaftar hanya mengelola iklan miliknya dan dapat login dari perangkat lain.

Sesi tamu versi lama tidak dihapus. Agar akses iklan lama tetap terhubung, daftar dari browser yang masih menyimpan sesi tersebut. Alurnya menghubungkan email ke identitas lama, memverifikasi email, kemudian mengatur password. Login langsung ke akun baru yang berbeda tidak otomatis memindahkan kepemilikan iklan lama.

## Admin pemilik web

Mode admin memakai login email/password yang terpisah dari sesi akun pengunjung. Akun yang terdaftar tidak otomatis menjadi admin. Keanggotaan admin berada pada tabel public.site_admins, yang tidak dapat dibaca atau diubah melalui klien publik. Dashboard pemilik dapat melihat, mengedit, mengubah status, dan menghapus semua iklan. Jasa reparasi hanya dapat ditambahkan atau diubah oleh admin. Favorit pribadi pengguna lain dan direktori akun Auth tidak ditampilkan pada dashboard.

Untuk menetapkan admin pertama, pemilik proyek harus membuat atau memilih akun Supabase Auth dengan email terkonfirmasi dan password. Tambahkan UUID akun yang benar ke public.site_admins melalui dashboard database. Jangan memberi hak admin berdasarkan nama, user_metadata, localStorage, atau password yang tertanam pada HTML. Pada proyek online ini, akun pemilik pertama sudah diberi peran admin. Password dibuat sendiri oleh pemilik melalui alur email terverifikasi.

## Pengaturan email yang diperlukan

Aktifkan email/password dan konfirmasi email, tentukan Site URL https://ovxan.github.io/second-life/ serta redirect URL https://ovxan.github.io/second-life/?account=verified dan https://ovxan.github.io/second-life/?account=recovery. Aktifkan manual identity linking untuk konversi sesi tamu lama. Anonymous sign-ins baru tidak dibutuhkan.

Pendaftaran, konversi akun lama, dan lupa password memerlukan layanan email. SMTP bawaan Supabase membatasi penerima dan tidak cukup untuk pendaftaran umum; pengelola perlu mengonfigurasi SMTP yang dapat mengirim email verifikasi kepada pengunjung. Jangan mematikan konfirmasi email untuk mengatasi kendala pengiriman. Kata sandi SMTP hanya diatur pada Supabase, tidak pernah dimasukkan ke repository.

## Database

Migrasi awal supabase/migrations/202611020001_second_life.sql telah diterapkan pada proyek yang dikonfigurasi. Migrasi akun/admin supabase/migrations/202611030001_repair_admin.sql menambahkan aturan akun terverifikasi dan peran pemilik tanpa menghapus data listing lama. Migrasi supabase/migrations/202611030002_manual_billing.sql menambahkan tagihan, verifikasi pembayaran, tujuan transfer, dan bucket bukti privat. Jalankan setiap migrasi satu kali, berurutan, pada proyek baru; jangan menjalankannya ulang pada proyek yang sama.

Kebijakan database menolak penulisan oleh sesi anonim, membatasi perubahan biasa ke pemilik iklan, membatasi reparasi ke admin, dan mencegah pengangkatan hak admin dari klien. Pergantian foto oleh moderator tetap memakai foto yang diunggah moderator tersebut. Foto bucket second-life-photos bersifat publik; metadata/hapus dibatasi pemilik dan admin. Foto maksimal 2 MB, JPG/PNG/WebP.

## Harga dan biaya admin

Harga formulir adalah bagian penjual. Untuk jual beli: harga barang + admin Rp5.000 menjadi total pembeli. Contoh Rp150.000 + Rp5.000 = Rp155.000; bagian penjual tetap Rp150.000. Donasi dan informasi jasa tidak dikenai biaya admin platform. Katalog, detail, formulir, filter/urutan, WhatsApp, dan salin info memakai perhitungan yang sama.

Harga barang dibayar langsung kepada penjual. Setelah jual beli berhasil, pembeli membuat tagihan admin Rp5.000 dari detail barang atau tautan barang melalui halaman Tagihan. Tautan masih dapat dipakai jika iklan sudah ditandai Terjual. Tidak ada pemotongan otomatis dari uang penjual.

Admin membuka #adminbilling, mengisi rekening bank/e-wallet milik pengelola, lalu mengaktifkan penagihan. Tanpa tujuan aktif, pembuatan tagihan ditolak di database. Rekening tidak ditanam di HTML. Tujuan dan harga pada tagihan disimpan saat tagihan dibuat agar perubahan berikutnya tidak mengubah tagihan lama.

Pembeli mentransfer Rp5.000 ke tujuan pada tagihan dan mengunggah bukti JPG/PNG/WebP maksimal 2 MB. Bukti disimpan sebagai JPEG pada bucket privat second-life-receipts. Hanya pembeli terkait dan admin dapat mengaksesnya; tautan gambar berlaku 60 detik. Status: Belum dibayar, Menunggu verifikasi, Perlu perbaikan, Lunas, Dibatalkan. Admin mencocokkan transfer dengan mutasi rekening/e-wallet sebelum mengonfirmasi Lunas. Bukti yang ditolak bisa diperbaiki dengan alasan yang terlihat oleh pembeli. Sistem mencatat riwayat perubahan dan bukti sebelumnya.

Rekap pendapatan mencakup seluruh biaya admin terkonfirmasi, bukan harga barang atau tagihan yang masih diperiksa. Daftar UI menampilkan 100 tagihan terbaru. Satu iklan mempunyai satu tagihan aktif untuk mencegah tagihan ganda. Tagihan lunas tidak bisa dibatalkan atau diedit melalui klien. Pembatalan tagihan belum dibayar tidak memindahkan atau mengembalikan uang. Refund transfer yang sudah masuk ditangani pengelola di luar web. Menghapus iklan tidak menghapus arsip tagihan. Status Terjual tidak otomatis membuktikan atau menagih biaya admin. Tidak ada promo potongan admin yang diaktifkan.

Penagihan manual bergantung pada pembeli membuat tagihan dan pengelola memeriksa transfer. Tidak ada koneksi bank, payment gateway, debit otomatis, atau jaminan pemungutan biaya pada transaksi di luar web.

## Pengembangan dan pemeriksaan

Gunakan Node.js 22 atau lebih baru dan pnpm.

    pnpm install
    pnpm exec tsc --noEmit
    pnpm test
    pnpm build

Sumber UI pada src/marketplace.tsx; autentikasi pada src/member-auth.ts dan src/admin-auth.ts; akses katalog pada src/online-api.ts. src/backend-config.json hanya berisi URL proyek dan publishable key publik. Jangan menambahkan secret key, password database, token sesi, atau kredensial SMTP ke kode.

tests/rls.mjs memeriksa kepemilikan, akun terverifikasi, role admin, dan kebijakan foto melalui PostgreSQL/PGlite. tests/pricing.mjs memeriksa 20 aturan perhitungan harga. tests/billing.mjs memeriksa 50 aturan tagihan, status, privasi bukti, rekap, riwayat, dan pembatasan akses melalui PostgreSQL/PGlite. Uji akses proyek online opsional: RUN_LIVE_TESTS=1 node tests/live.mjs; pengujian ini tidak membuat data atau akun baru.

Iklan berlabel Contoh merupakan demonstrasi, bukan penawaran asli. Foto ilustrasi: Unsplash. Identitas kampus belum diverifikasi. Pendaftaran akun mengurangi penyalahgunaan, tetapi bukan verifikasi identitas atau jaminan bebas penipuan.
