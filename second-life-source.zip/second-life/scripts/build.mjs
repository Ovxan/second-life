import * as esbuild from 'esbuild';
import { readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = fileURLToPath(new URL('../', import.meta.url));
const config = JSON.parse(await readFile(path.join(root, 'src/backend-config.json'), 'utf8'));
if (!/^https:\/\/[a-z0-9]+\.supabase\.co$/.test(config.url) || !/^sb_publishable_/.test(config.publishableKey)) {
  throw new Error('Configure a Supabase project URL and public publishable key before building. Never use a secret key.');
}
const built = await esbuild.build({
  entryPoints: [path.join(root, 'src/entry.tsx')], bundle: true, minify: true,
  write: false, format: 'iife', platform: 'browser', target: ['es2020'],
  jsx: 'automatic', loader: { '.jpg': 'dataurl' },
  define: { 'process.env.NODE_ENV': '"production"' }, legalComments: 'inline',
});
const js = built.outputFiles[0].text;
const css = await readFile(path.join(root, 'src/style.css'), 'utf8');
const favicon = (await readFile(path.join(root, 'src/favicon.txt'), 'utf8')).trim();
const html = `<!DOCTYPE html>
<!-- Second Life: single-file HTML. Shared listings and photos use Supabase. Only the public publishable key is included. -->
<html lang="id"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="color-scheme" content="light">
<title>Second Life — Barang Lama, Cerita Baru</title>
<meta name="description" content="Jual beli, donasi, dan jasa reparasi untuk mahasiswa dan alumni. Pasang barang ke katalog online bersama dan lanjutkan manfaatnya.">
<link rel="icon" href="${favicon}">
<style>${css}</style>
</head><body>
<div id="root"><p style="padding:40px;font:16px Arial;color:#365c40">Menyiapkan Second Life…</p></div>
<noscript><p style="padding:30px;font:16px Arial">Aktifkan JavaScript dan koneksi internet untuk menggunakan katalog bersama Second Life.</p></noscript>
<script>${js.replaceAll('</script', '<\\/script')}</script>
</body></html>`;
if (/chatgpt|sb_secret_[A-Za-z0-9_-]+|service_role/i.test(html)) throw new Error('Unexpected forbidden runtime dependency or secret in HTML.');
if (/<script[^>]+src=/i.test(html)) throw new Error('The standalone HTML must embed its scripts.');
await writeFile(path.join(root, 'index.html'), html);
console.log(`Built standalone online index.html (${Buffer.byteLength(html)} bytes), 7 embedded photos.`);
