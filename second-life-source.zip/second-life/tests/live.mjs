import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createClient } from '@supabase/supabase-js';
if (process.env.RUN_LIVE_TESTS !== '1') throw new Error('Set RUN_LIVE_TESTS=1 to check the configured project.');
const config=JSON.parse(await readFile(new URL('../src/backend-config.json',import.meta.url),'utf8'));
const db=createClient(config.url,config.publishableKey,{auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false}});
let checks=0;
const ok=(condition,name)=>{assert.ok(condition,name);console.log('PASS '+(++checks)+': '+name);};
try{
 const catalog=await db.from('listings').select('id,kind,status').limit(1000);
 ok(!catalog.error,'visitors can read the shared public catalog');
 const member=await db.rpc('has_registered_account');ok(!member.error&&member.data===false,'a visitor has no registered-account write access');
 const admin=await db.rpc('is_site_admin');ok(!admin.error&&admin.data===false,'a visitor has no owner admin role');
 const role=await db.from('site_admins').select('user_id');ok(!!role.error,'admin membership cannot be inspected by visitors');
 const escalation=await db.from('site_admins').insert({user_id:'00000000-0000-4000-8000-000000000000'});ok(!!escalation.error,'visitors cannot assign themselves an admin role');
 const service=await db.from('listings').insert({kind:'jasa',title:'Permintaan uji harus ditolak',category:'Elektronik',description:'Permintaan pemeriksaan izin yang wajib ditolak sebelum ditulis.',condition:'Baik',location:'Lingkungan uji',price:0,photo_path:'',seller_name:'Uji akses',phone:'628000000000'});
 ok(!!service.error,'a visitor cannot post a repair service');
 console.log(checks+' live access checks passed; no fixtures created.');
}finally{await db.removeAllChannels();}
process.exit(0);
