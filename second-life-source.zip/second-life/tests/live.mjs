// Explicit opt-in: creates two guest sessions and a clearly marked temporary
// listing/photo, then removes the fixtures using the owning session only.
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createClient } from '@supabase/supabase-js';

if (process.env.RUN_LIVE_TESTS !== '1') throw new Error('Set RUN_LIVE_TESTS=1 to run against the configured project.');
const config = JSON.parse(await readFile(new URL('../src/backend-config.json', import.meta.url), 'utf8'));
const make = () => createClient(config.url, config.publishableKey, { auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false } });
const a = make(), b = make(), publicReader = make();
let photoPath, itemId, channel, checks = 0;
const ok = (condition, message) => { assert.ok(condition, message); console.log(`PASS ${++checks}: ${message}`); };
const noError = (result) => { assert.equal(result.error, null, result.error?.message); return result.data; };
try {
  const owner = noError(await a.auth.signInAnonymously()).user;
  const other = noError(await b.auth.signInAnonymously()).user;
  ok(owner.id !== other.id, 'two independent guest identities');
  photoPath = `${owner.id}/${crypto.randomUUID()}.jpg`;
  const photo = await readFile(new URL('../src/assets/plant.jpg', import.meta.url));
  noError(await a.storage.from('second-life-photos').upload(photoPath, photo, { contentType: 'image/jpeg' }));
  ok(true, 'owner can upload a photo');
  const publicPhoto = a.storage.from('second-life-photos').getPublicUrl(photoPath).data.publicUrl;
  ok((await fetch(publicPhoto)).ok, 'photo is visible to a public visitor');
  const forbiddenPhoto = await b.storage.from('second-life-photos').upload(`${owner.id}/${crypto.randomUUID()}.jpg`, photo, { contentType: 'image/jpeg' });
  ok(!!forbiddenPhoto.error, 'other guest cannot upload into owner photo folder');

  let resolveEvent;
  const event = new Promise(resolve => { resolveEvent = resolve; });
  const subscription = new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('Realtime subscription timed out')), 15000);
    channel = b.channel('test-' + crypto.randomUUID()).on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'listings' }, payload => {
      if (payload.new.title.startsWith('[PENGUJIAN]')) resolveEvent(payload.new.id);
    }).subscribe(status => { if (status === 'SUBSCRIBED') { clearTimeout(timer); resolve(); } });
  });
  await subscription;
  const row = {
    kind: 'jual', title: '[PENGUJIAN] Katalog bersama Second Life', category: 'Perlengkapan Kos',
    description: 'Iklan sementara untuk pengujian sistem. Bukan penawaran barang. Jangan dihubungi; iklan akan dibersihkan setelah pengujian.',
    condition: 'Baik', location: 'Area pengujian', price: 1000, photo_path: photoPath,
    seller_name: 'Uji sistem', phone: '628000000000',
  };
  const listing = noError(await a.from('listings').insert(row).select('id').single()); itemId = listing.id;
  ok(!!itemId, 'owner can create an actual listing');
  const received = await Promise.race([event, new Promise(resolve => setTimeout(() => resolve(null), 15000))]);
  ok(received === itemId, 'second guest receives realtime catalog insert');
  ok(noError(await publicReader.from('listings').select('id').eq('id', itemId)).length === 1, 'visitor without a session can read the shared listing');
  ok(noError(await b.from('listings').select('id').eq('id', itemId)).length === 1, 'second guest reads the same listing');
  const changed = await b.from('listings').update({ title: 'Percobaan perubahan oleh pengunjung lain' }).eq('id', itemId).select('id');
  ok(!changed.error && changed.data.length === 0, 'other guest cannot edit the listing');
  const removed = await b.from('listings').delete().eq('id', itemId).select('id');
  ok(!removed.error && removed.data.length === 0, 'other guest cannot delete the listing');
  noError(await b.from('favorites').upsert({ listing_id: itemId }, { onConflict: 'owner_id,listing_id', ignoreDuplicates: true }));
  noError(await b.from('favorites').upsert({ listing_id: itemId }, { onConflict: 'owner_id,listing_id', ignoreDuplicates: true }));
  ok(noError(await b.from('favorites').select('listing_id').eq('listing_id', itemId)).length === 1, 'guest can save a favorite without duplicates');
  ok(noError(await a.from('favorites').select('listing_id').eq('listing_id', itemId)).length === 0, 'favorites remain private to their owner');
  noError(await a.from('listings').update({ status: 'Terjual' }).eq('id', itemId));
  ok(noError(await publicReader.from('listings').select('id').eq('id', itemId)).length === 0, 'closed listing leaves the public catalog');
  ok(noError(await a.from('listings').select('id').eq('id', itemId)).length === 1, 'owner can still manage a closed listing');
} finally {
  if (channel) await b.removeChannel(channel);
  if (itemId) noError(await a.from('listings').delete().eq('id', itemId));
  if (photoPath) noError(await a.storage.from('second-life-photos').remove([photoPath]));
  if (itemId) ok(noError(await b.from('favorites').select('listing_id').eq('listing_id', itemId)).length === 0, 'test cleanup cascades favorites');
  await Promise.all([a.auth.signOut(), b.auth.signOut()]);
}
console.log(`${checks} live shared-database checks passed; listing and photo fixtures removed.`);
process.exit(0);
