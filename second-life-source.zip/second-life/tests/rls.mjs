import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { PGlite } from '@electric-sql/pglite';
const pg=new PGlite(); const A='11111111-1111-4111-8111-111111111111', B='22222222-2222-4222-8222-222222222222', P='aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa.jpg';
let checks=0;
const equal=(a,b,label)=>{assert.deepEqual(a,b,label);checks++;};
async function role(name,uid,fn){await pg.exec('begin');try{await pg.exec('set local role '+name);await pg.query("select set_config('request.jwt.claim.sub',$1,true)",[uid||'']);const value=await fn();await pg.exec('commit');return value;}catch(e){await pg.exec('rollback');throw e;}}
const owner=(uid,fn)=>role('authenticated',uid,fn);
async function fails(fn){await assert.rejects(fn);checks++;}
async function add(uid,extra={}){return owner(uid,async()=>{const value={kind:'jual',title:'Meja uji bersama',category:'Furnitur',description:'Barang uji sementara untuk memeriksa perlindungan akses pemilik.',condition:'Baik',location:'Lingkungan uji',price:5000,photo_path:uid+'/'+P,seller_name:'Pemilik uji',phone:'6280000000000',...extra};const names=Object.keys(value);return(await pg.query('insert into public.listings('+names.join(',')+') values('+names.map((_,i)=>'$'+(i+1)).join(',')+') returning id,owner_id',Object.values(value))).rows[0];});}
try{
 await pg.exec(`create role anon; create role authenticated; create schema auth; create schema storage;
 create table auth.users(id uuid primary key);
 create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;
 grant usage on schema auth,storage to anon,authenticated; grant execute on function auth.uid() to anon,authenticated;
 create table storage.buckets(id text primary key,name text,public boolean,file_size_limit bigint,allowed_mime_types text[]);
 create table storage.objects(id uuid primary key default gen_random_uuid(),bucket_id text references storage.buckets(id),name text,owner_id text);
 alter table storage.objects enable row level security; grant select,insert,delete on storage.objects to authenticated;
 create function storage.foldername(name text) returns text[] language sql immutable as $$select string_to_array(regexp_replace(name,'/[^/]*$',''),'/')$$;
 create function storage.extension(name text) returns text language sql immutable as $$select split_part(name,'.',-1)$$;
 insert into auth.users values('${A}'),('${B}');`);
 await pg.exec(await readFile('supabase/migrations/202611020001_second_life.sql','utf8'));
 equal((await pg.query("select relrowsecurity from pg_class where oid='public.listings'::regclass")).rows[0].relrowsecurity,true,'Catalog RLS enabled');
 equal((await pg.query("select relrowsecurity from pg_class where oid='public.favorites'::regclass")).rows[0].relrowsecurity,true,'Favorite RLS enabled');
 const sale=await add(A); equal(sale.owner_id,A,'Owner assigned from verified identity');
 equal(await role('anon',null,async()=>(await pg.query('select id from public.listings')).rows.length),1,'Public reads shared active catalog');
 equal(await owner(B,async()=>(await pg.query('update public.listings set title=$1 where id=$2 returning id',['Perubahan tidak sah',sale.id])).rows.length),0,'Other owner cannot edit');
 equal(await owner(B,async()=>(await pg.query('delete from public.listings where id=$1 returning id',[sale.id])).rows.length),0,'Other owner cannot delete');
 await fails(()=>owner(B,()=>pg.query('insert into public.listings(owner_id) values($1)',[A])));
 await fails(()=>role('anon',null,()=>pg.query("insert into public.listings(kind) values('jasa')")));
 await fails(()=>owner(A,()=>pg.query('update public.listings set owner_id=$1 where id=$2',[B,sale.id])));
 await fails(()=>owner(A,()=>pg.query("update public.listings set kind='jasa' where id=$1",[sale.id])));
 await fails(()=>owner(A,()=>pg.query("update public.listings set status='Tersalurkan' where id=$1",[sale.id])));
 await fails(()=>owner(A,()=>pg.query('update public.listings set price=0 where id=$1',[sale.id])));
 await fails(()=>add(A,{photo_path:B+'/'+P}));
 await owner(B,()=>pg.query('insert into public.favorites(listing_id) values($1)',[sale.id]));
 equal(await owner(A,async()=>(await pg.query('select * from public.favorites')).rows.length),0,'Favorites are private');
 equal(await owner(B,async()=>(await pg.query('select * from public.favorites')).rows.length),1,'Owner reads favorite');
 await fails(()=>role('anon',null,()=>pg.query('select * from public.favorites')));
 await owner(A,()=>pg.query("update public.listings set status='Terjual' where id=$1",[sale.id]));
 equal(await role('anon',null,async()=>(await pg.query('select * from public.listings')).rows.length),0,'Sold records hidden from public');
 equal(await owner(A,async()=>(await pg.query('select * from public.listings')).rows.length),1,'Owner retains sold record');
 equal(await owner(B,async()=>(await pg.query('select * from public.listings')).rows.length),0,'Other owner cannot read closed record');
 await owner(A,()=>pg.query('insert into storage.objects(bucket_id,name) values($1,$2)',['second-life-photos',A+'/'+P]));
 await fails(()=>owner(B,()=>pg.query('insert into storage.objects(bucket_id,name) values($1,$2)',['second-life-photos',A+'/'+P])));
 equal(await owner(B,async()=>(await pg.query('select * from storage.objects')).rows.length),0,'Photo metadata remains owner-only');
 equal(await owner(B,async()=>(await pg.query('delete from storage.objects returning id')).rows.length),0,'Other owner cannot remove photo');
 const gift=await add(A,{kind:'donasi',price:0});
 await owner(A,()=>pg.query("update public.listings set status='Tersalurkan' where id=$1",[gift.id]));
 await fails(()=>add(A,{kind:'donasi',price:1000}));
 await owner(A,()=>pg.query('delete from public.listings where id=$1',[sale.id]));
 equal(await owner(B,async()=>(await pg.query('select * from public.favorites')).rows.length),0,'Delete cascades favorites');
 console.log(checks+' Postgres policy and integrity checks passed.');
}finally{await pg.close();}
