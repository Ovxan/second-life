import assert from 'node:assert/strict';
import { build } from 'esbuild';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { createRequire } from 'node:module';

const temporary=await mkdtemp(path.join(tmpdir(),'second-life-visibility-'));
let checks=0;
try{
 const file=path.join(temporary,'visibility.cjs');
 await build({stdin:{contents:`export { default as Marketplace } from './src/marketplace'; export { MemberAccount } from './src/components/member-account'; export { CampusReviewLabel } from './src/components/campus-verification'; export { adminClient } from './src/admin-auth'; export { memberClient } from './src/member-auth'; export { createElement } from 'react'; export { renderToStaticMarkup } from 'react-dom/server';`,resolveDir:process.cwd(),loader:'ts'},bundle:true,platform:'node',format:'cjs',outfile:file,jsx:'automatic',loader:{'.jpg':'dataurl'},logLevel:'silent'});
 const {Marketplace,MemberAccount,CampusReviewLabel,adminClient,memberClient,createElement,renderToStaticMarkup}=createRequire(import.meta.url)(file);
 const check=(label,fn)=>{fn();checks++;console.log('PASS '+checks+': '+label);};
 const guest=renderToStaticMarkup(createElement(Marketplace));
 check('public homepage has no owner management entry',()=>assert.doesNotMatch(guest,/Dashboard pemilik|Mode admin pemilik|Penagihan &amp; pendapatan|Masuk mode admin/));
 check('public homepage keeps buyer billing available',()=>assert.match(guest,/Tagihan saya/));
 globalThis.location={search:''};
 const props={user:{id:'11111111-1111-4111-8111-111111111111',name:'Akun uji',email:'member@example.invalid',canPost:true},updated:async()=>{},manage:()=>{}};
 const member=renderToStaticMarkup(createElement(MemberAccount,props));
 check('ordinary signed-in account has no owner management actions',()=>assert.doesNotMatch(member,/Dashboard pemilik|Penagihan &amp; pendapatan|Akses pemilik web terverifikasi/));
 const owner=renderToStaticMarkup(createElement(MemberAccount,{...props,ownerActions:{dashboard:()=>{},billing:()=>{}}}));
 check('approved owner account exposes both owner destinations',()=>{assert.match(owner,/Dashboard pemilik/);assert.match(owner,/Penagihan &amp; pendapatan/);});
 check('owner operations use the same account login session',()=>assert.equal(adminClient(),memberClient()));
 check('registered member sees private campus submission workflow',()=>assert.match(member,/Verifikasi dokumen kampus/));
 check('campus review administration stays hidden from guests and members',()=>{assert.doesNotMatch(guest,/Pemeriksaan dokumen kampus/);assert.doesNotMatch(member,/Pemeriksaan dokumen kampus/);});
 const campusOwner=renderToStaticMarkup(createElement(MemberAccount,{...props,ownerActions:{dashboard:()=>{},billing:()=>{},verification:()=>{}}}));
 check('approved owner can open document review without self-approval',()=>{assert.match(campusOwner,/Pemeriksaan dokumen kampus/);assert.doesNotMatch(campusOwner,/Kirim untuk diperiksa/);});
 check('unreviewed seller never receives a positive document label',()=>assert.match(renderToStaticMarkup(createElement(CampusReviewLabel,{})),/belum ditinjau/));
 check('positive label describes manual document review accurately',()=>{const label=renderToStaticMarkup(createElement(CampusReviewLabel,{campus:'Kampus Uji'}));assert.match(label,/Dokumen kampus ditinjau admin/);assert.doesNotMatch(label,/dijamin|resmi|WhatsApp terverifikasi/);});
 await memberClient().auth.stopAutoRefresh();
 console.log(checks+' owner visibility and shared-session checks passed.');
}finally{await rm(temporary,{recursive:true,force:true});}
