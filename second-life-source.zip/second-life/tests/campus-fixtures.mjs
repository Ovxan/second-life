import {readFile} from 'node:fs/promises';

// Isolated database fixtures stand for previously reviewed documents whose
// photos were removed. Production migrations never approve existing accounts.
export async function installCampusFixtures(pg,users){
  await pg.exec(await readFile('supabase/migrations/202611030004_campus_verification.sql','utf8'));
  for(const id of users)await pg.query("insert into public.campus_verifications(user_id,full_name,campus,document_kind,status,reviewed_at,document_deleted_at) values($1,'Pemilik uji','Kampus Uji','ktm','approved',now(),now())",[id]);
}
