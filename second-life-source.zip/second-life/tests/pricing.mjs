import assert from 'node:assert/strict';
import { build } from 'esbuild';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
const temporary = await mkdtemp(path.join(tmpdir(), 'second-life-pricing-'));
let checks = 0;
const check = (name, test) => { test(); checks++; console.log(`PASS ${checks}: ${name}`); };
try {
  const outfile = path.join(temporary, 'pricing.cjs');
  await build({
    stdin: { contents: `export * from './src/lib/pricing'; export * from './src/components/pricing'; export { makeListingText } from './src/online-api'; export { createElement } from 'react'; export { renderToStaticMarkup } from 'react-dom/server';`, resolveDir: root, loader: 'ts' },
    bundle: true, platform: 'node', format: 'cjs', outfile, jsx: 'automatic', logLevel: 'silent',
  });
  const { saleQuote, catalogPrice, pricingText, PriceBreakdown, ListingPrice, createElement, renderToStaticMarkup, makeListingText } = createRequire(import.meta.url)(outfile);
  check('Rp150.000 sale adds one Rp5.000 fee and keeps seller proceeds', () => {
    assert.deepEqual(saleQuote(150000), { itemPrice: 150000, adminFee: 5000, buyerTotal: 155000, sellerReceives: 150000 });
  });
  check('smallest sale never subtracts the fee from the seller', () => assert.equal(saleQuote(1000).sellerReceives, 1000));
  check('maximum price remains an exact integer after adding the fee', () => assert.equal(saleQuote(100000000).buyerTotal, 100005000));
  for (const value of [NaN, Infinity, -1, 0, 999, 1500.5, 100000001]) {
    check(`invalid price ${value} is rejected`, () => assert.throws(() => saleQuote(value)));
  }
  check('donations have no admin charge', () => assert.equal(catalogPrice({ kind: 'donasi', price: 0 }), 0));
  check('service information has no platform admin charge', () => assert.equal(catalogPrice({ kind: 'jasa', price: 0 }), 0));
  check('catalog filters use the displayed buyer total', () => {
    const item = { kind: 'jual', price: 150000 };
    assert.equal(catalogPrice(item) <= 150000, false);
    assert.equal(catalogPrice(item) <= 155000, true);
    assert.equal(item.price, 150000);
  });
  check('sale card displays total and exposes its base price', () => {
    const html = renderToStaticMarkup(createElement(ListingPrice, { kind: 'jual', price: 150000 }));
    assert.match(html, /155\.000/); assert.match(html, /150\.000/); assert.match(html, /admin/);
  });
  check('donation card remains free', () => {
    const html = renderToStaticMarkup(createElement(ListingPrice, { kind: 'donasi', price: 0 }));
    assert.match(html, /Gratis/); assert.doesNotMatch(html, /5\.000/);
  });
  check('empty form has no fake payable total', () => {
    const html = renderToStaticMarkup(createElement(PriceBreakdown, { price: 0, preview: true }));
    assert.match(html, /Isi harga barang/); assert.match(html, /<dd>—<\/dd>/); assert.doesNotMatch(html, /NaN|Infinity/);
  });
  check('breakdown identifies the recipient and explains separate manually verified payment', () => {
    const html = renderToStaticMarkup(createElement(PriceBreakdown, { price: 150000 }));
    assert.match(html, /pengelola Second Life/); assert.match(html, /ditransfer terpisah ke pengelola/);
  });
  check('contact text contains the complete quote', () => {
    const text = pricingText({ kind: 'jual', price: 150000 });
    assert.match(text, /Total barang \+ admin: Rp\s*155\.000/);
    assert.match(text, /Bagian penjual: Rp\s*150\.000/);
    assert.match(text, /Biaya admin Second Life: Rp\s*5\.000/);
  });
  check('shared listing text uses the same quote', () => {
    const text = makeListingText({ title: 'Meja uji', kind: 'jual', price: 150000, condition: 'Baik', location: 'Area kampus', description: 'Contoh pengujian', phone: '', demo: true });
    assert.match(text, /155\.000/); assert.match(text, /ditransfer terpisah ke pengelola/);
  });
  check('free listing text never adds a sale fee', () => assert.equal(pricingText({ kind: 'donasi', price: 0 }), 'Donasi gratis · tanpa biaya admin'));
  console.log(`${checks} pricing checks passed.`);
} finally { await rm(temporary, { recursive: true, force: true }); }
